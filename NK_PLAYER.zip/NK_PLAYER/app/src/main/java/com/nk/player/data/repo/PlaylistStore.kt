package com.nk.player.data.repo

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "playlists")
data class PlaylistEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val createdAt: Long = System.currentTimeMillis())
@Entity(tableName = "playlist_items", primaryKeys = ["playlistId","mediaUri"], foreignKeys = [ForeignKey(entity = PlaylistEntity::class, parentColumns = ["id"], childColumns = ["playlistId"], onDelete = ForeignKey.CASCADE)])
data class PlaylistItemEntity(val playlistId: Long, val mediaUri: String, val title: String, val position: Int)
@Entity(tableName = "favorites", primaryKeys = ["mediaUri"])
data class FavoriteEntity(val mediaUri: String, val title: String, val addedAt: Long = System.currentTimeMillis())

@Dao
interface NKDao {
    @Query("SELECT * FROM playlists ORDER BY createdAt DESC") fun playlists(): Flow<List<PlaylistEntity>>
    @Insert suspend fun insertPlaylist(e: PlaylistEntity): Long
    @Query("DELETE FROM playlists WHERE id=:id") suspend fun deletePlaylist(id: Long)
    @Query("SELECT * FROM playlist_items WHERE playlistId=:pid ORDER BY position") fun items(pid: Long): Flow<List<PlaylistItemEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun addItem(e: PlaylistItemEntity)
    @Query("DELETE FROM playlist_items WHERE playlistId=:pid AND mediaUri=:uri") suspend fun removeItem(pid: Long, uri: String)
    @Query("SELECT * FROM favorites") fun favorites(): Flow<List<FavoriteEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun fav(e: FavoriteEntity)
    @Query("DELETE FROM favorites WHERE mediaUri=:uri") suspend fun unfav(uri: String)
    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE mediaUri=:uri)") suspend fun isFav(uri: String): Boolean
}

@Database(entities = [PlaylistEntity::class, PlaylistItemEntity::class, FavoriteEntity::class], version = 1, exportSchema = false)
abstract class NKDatabase : RoomDatabase() { abstract fun dao(): NKDao
    companion object {
        @Volatile private var I: NKDatabase? = null
        fun get(c: Context): NKDatabase = I ?: synchronized(this) {
            I ?: Room.databaseBuilder(c.applicationContext, NKDatabase::class.java, "nk_player.db").build().also { I = it }
        }
    }
}
