package com.personal.myplayer

import android.content.Context
import android.content.SharedPreferences

/** Resume positions, favourites and history. Keys look like "v123" (video) or "a456" (audio). */
object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(ctx: Context) {
        sp = ctx.applicationContext.getSharedPreferences("myplayer", Context.MODE_PRIVATE)
    }

    fun getPos(key: String): Long = sp.getLong("pos_$key", 0L)

    fun setPos(key: String, ms: Long) {
        val e = sp.edit()
        if (ms <= 0L) e.remove("pos_$key") else e.putLong("pos_$key", ms)
        e.apply()
    }

    /** Saves resume position; clears it when the item is (almost) finished or just started. */
    fun savePos(key: String, pos: Long, dur: Long) {
        if (dur > 0 && pos > dur - 5_000) setPos(key, 0L)
        else if (pos > 3_000) setPos(key, pos)
    }

    fun favourites(): Set<String> = sp.getStringSet("favs", emptySet())!!.toSet()

    fun toggleFav(key: String): Set<String> {
        val s = favourites().toMutableSet()
        if (!s.add(key)) s.remove(key)
        sp.edit().putStringSet("favs", s).apply()
        return s
    }

    fun history(): List<String> =
        (sp.getString("history", "") ?: "").split(",").filter { it.isNotEmpty() }

    fun addHistory(key: String) {
        val l = history().toMutableList()
        l.remove(key)
        l.add(0, key)
        sp.edit().putString("history", l.take(100).joinToString(",")).apply()
    }

    fun clearHistory() {
        sp.edit().remove("history").apply()
    }
}
