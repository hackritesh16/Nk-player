package com.nk.player.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nk.player.ui.theme.NKColors

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    radius: Dp = 20.dp,
    border: Boolean = true,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = modifier.clip(RoundedCornerShape(radius)),
        shape = RoundedCornerShape(radius),
        color = NKColors.Glass,
        border = if (border) BorderStroke(1.dp, NKColors.GlassBorder) else null,
        tonalElevation = 0.dp
    ) { Column(modifier = Modifier.fillMaxWidth(), content = content) }
}

@Composable
fun NeonGradientBackground(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.background(
            Brush.radialGradient(
                colors = listOf(Color(0x3300F0FF), Color(0x227C3AED), Color(0x11060B1A), NKColors.Bg),
                radius = 1200f
            )
        )
    )
}

@Composable
fun GlowDot(modifier: Modifier = Modifier, color: Color = NKColors.Cyan) {
    Box(
        modifier
            .size(8.dp)
            .clip(RoundedCornerShape(50))
            .background(color)
            .blur(6.dp)
    )
}
