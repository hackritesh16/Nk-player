package com.nk.player.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nk.player.data.model.MediaItem
import com.nk.player.data.repo.*
import com.nk.player.ui.components.GlassCard
import com.nk.player.ui.theme.NKColors
import kotlinx.coroutines.launch

@Composable
fun PlaylistsScreen(
    all: List<MediaItem>,
    playlists: List<PlaylistEntity>,
    favs: List<FavoriteEntity>,
    onPlayUris: (List<String>, Int)->Unit,
    dao: NKDao
){
    val scope = rememberCoroutineScope()
    var showCreate by remember{ mutableStateOf(false) }
    var newName by remember{ mutableStateOf("") }
    var selectedPid by remember{ mutableStateOf<Long?>(null) }

    Column(Modifier.fillMaxSize().background(NKColors.Bg).padding(16.dp)){
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()){
            Text("Playlists", style = MaterialTheme.typography.displayMedium, color = NKColors.TextPri, modifier = Modifier.weight(1f))
            Button(onClick = { showCreate = true }, colors = ButtonDefaults.buttonColors(containerColor = NKColors.Cyan, contentColor = NKColors.Bg)){ Text("+ New") }
        }
        Spacer(Modifier.height(6.dp))
        Text("Favorites • ${favs.size} • Playlists • ${playlists.size}", color = NKColors.TextSec, style = MaterialTheme.typography.bodyMedium)
        if(selectedPid!=null){ Spacer(Modifier.height(8.dp)); AssistChip(onClick = { selectedPid=null }, label = { Text("← Back") }) }

        if(showCreate){
            Spacer(Modifier.height(12.dp))
            GlassCard{
                Column(Modifier.padding(12.dp)){
                    OutlinedTextField(value=newName, onValueChange={newName=it}, label={ Text("Playlist name") }, modifier=Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)){
                        Button(onClick={ if(newName.isNotBlank()){ scope.launch{ dao.insertPlaylist(PlaylistEntity(name=newName.trim())); newName=""; showCreate=false } } }, colors = ButtonDefaults.buttonColors(containerColor=NKColors.Violet)){ Text("Create") }
                        TextButton(onClick={ showCreate=false }){ Text("Cancel", color=NKColors.TextSec) }
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        if(selectedPid==null){
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxSize()){
                item{
                    GlassCard(modifier = Modifier.clickable{
                        if(favs.isNotEmpty()) onPlayUris(favs.map{ it.mediaUri }, 0)
                    }){
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically){
                            Icon(Icons.Default.Favorite, null, tint=NKColors.Pink); Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)){ Text("Favorites", color=NKColors.TextPri, style=MaterialTheme.typography.titleMedium); Text("${favs.size} tracks", color=NKColors.TextSec, style=MaterialTheme.typography.bodyMedium) }
                            if(favs.isNotEmpty()) Icon(Icons.Default.PlayArrow, null, tint=NKColors.Cyan)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                }
                items(playlists, key={it.id}){ pl ->
                    GlassCard(modifier = Modifier.clickable{ selectedPid = pl.id }){
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment=Alignment.CenterVertically){
                            Icon(Icons.Default.QueueMusic, null, tint=NKColors.Cyan); Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)){ Text(pl.name, color=NKColors.TextPri, style=MaterialTheme.typography.titleMedium); Text("Tap to open • long actions in detail", color=NKColors.TextSec, style=MaterialTheme.typography.bodyMedium) }
                            IconButton(onClick={ scope.launch{ dao.deletePlaylist(pl.id) } }){ Icon(Icons.Default.Delete, null, tint=NKColors.TextMuted) }
                        }
                    }
                }
                if(playlists.isEmpty() && favs.isEmpty()){
                    item{ Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment=Alignment.Center){ Text("Create your first playlist", color=NKColors.TextSec) } }
                }
            }
        } else {
            // Items of selected playlist
            val pid = selectedPid!!
            var items by remember(pid){ mutableStateOf<List<PlaylistItemEntity>>(emptyList()) }
            LaunchedEffect(pid){ dao.items(pid).collect{ items = it } }
            if(items.isEmpty()){
                GlassCard{ Column(Modifier.padding(16.dp)){
                    Text("Empty playlist", color=NKColors.TextPri, style=MaterialTheme.typography.titleMedium)
                    Text("Add from Library: tap ☆ on any track then add via + button in detail (or use quick add below).", color=NKColors.TextSec, style=MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(12.dp))
                    // Quick add: show first 30 media as add buttons
                    Text("Quick add", color=NKColors.Cyan, style=MaterialTheme.typography.labelLarge)
                } }
                Spacer(Modifier.height(8.dp))
                LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp), modifier=Modifier.fillMaxSize()){
                    items(all.take(30), key={it.id}){ m ->
                        GlassCard{
                            Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment=Alignment.CenterVertically){
                                Column(Modifier.weight(1f)){ Text(m.title, color=NKColors.TextPri, maxLines=1); Text(m.artist ?: "Unknown", color=NKColors.TextSec, style=MaterialTheme.typography.bodyMedium, maxLines=1) }
                                IconButton(onClick={ scope.launch{ dao.addItem(PlaylistItemEntity(pid, m.uri.toString(), m.title, items.size)) } }){ Icon(Icons.Default.Add, null, tint=NKColors.Cyan) }
                            }
                        }
                    }
                }
            } else {
                LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp), modifier=Modifier.fillMaxSize()){
                    item{
                        Button(onClick={ onPlayUris(items.map{ it.mediaUri }, 0) }, colors=ButtonDefaults.buttonColors(containerColor=NKColors.Cyan, contentColor=NKColors.Bg), modifier=Modifier.fillMaxWidth()){ Icon(Icons.Default.PlayArrow,null); Spacer(Modifier.width(8.dp)); Text("Play all (${items.size})") }
                        Spacer(Modifier.height(8.dp))
                    }
                    items(items, key={it.mediaUri}){ e ->
                        GlassCard{
                            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment=Alignment.CenterVertically){
                                Column(Modifier.weight(1f).clickable{ onPlayUris(items.map{ it.mediaUri }, items.indexOf(e)) }){ Text(e.title, color=NKColors.TextPri, maxLines=1); Text(e.mediaUri.substringAfterLast("/"), color=NKColors.TextMuted, style=MaterialTheme.typography.bodyMedium, maxLines=1) }
                                IconButton(onClick={ scope.launch{ dao.removeItem(pid, e.mediaUri) } }){ Icon(Icons.Default.Close, null, tint=NKColors.TextMuted) }
                            }
                        }
                    }
                }
            }
        }
    }
}
