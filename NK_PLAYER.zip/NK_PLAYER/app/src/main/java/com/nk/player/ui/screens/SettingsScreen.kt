package com.nk.player.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.nk.player.ui.components.GlassCard
import com.nk.player.ui.theme.NKColors

@Composable
fun SettingsScreen(
    theme: String,
    onTheme: (String)->Unit,
    onOpenEqualizer: ()->Unit,
    subtitlesScale: Float,
    onSubtitlesScale: (Float)->Unit,
){
    Column(Modifier.fillMaxSize().background(NKColors.Bg).verticalScroll(rememberScrollState()).padding(16.dp)){
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Brush.linearGradient(listOf(NKColors.Violet, NKColors.Cyan))).padding(20.dp)){
            Text("NK PLAYER", color = Color.White, style = MaterialTheme.typography.displayMedium)
            Spacer(Modifier.height(4.dp)); Text("Futuristic glassmorphism • neon cyan & purple • premium playback", color = Color(0xDDFFFFFF), style = MaterialTheme.typography.bodyMedium)
        }
        Spacer(Modifier.height(16.dp))

        Text("Appearance", color = NKColors.Cyan, style = MaterialTheme.typography.labelLarge)
        Spacer(Modifier.height(8.dp))
        GlassCard{
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)){
                Text("Theme", color=NKColors.TextPri, style=MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    listOf("dark" to "Dark", "neon" to "Neon", "amoled" to "AMOLED").forEach{ (k,label) ->
                        FilterChip(selected = theme==k, onClick={ onTheme(k) }, label={ Text(label) },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor=NKColors.Cyan, selectedLabelColor=NKColors.Bg))
                    }
                }
                HorizontalDivider(color=NKColors.Divider)
                Row(verticalAlignment=Alignment.CenterVertically, modifier=Modifier.fillMaxWidth()){
                    Icon(Icons.Default.Subtitles, null, tint=NKColors.TextSec); Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)){ Text("Subtitle size", color=NKColors.TextPri); Text("${(subtitlesScale*100).toInt()}%", color=NKColors.TextSec, style=MaterialTheme.typography.bodyMedium) }
                    Slider(value=subtitlesScale, onValueChange=onSubtitlesScale, valueRange=0.6f..1.8f, modifier=Modifier.width(140.dp), colors=SliderDefaults.colors(activeTrackColor=NKColors.Cyan, thumbColor=NKColors.Cyan))
                }
                Button(onClick=onOpenEqualizer, colors=ButtonDefaults.buttonColors(containerColor=NKColors.Violet), modifier=Modifier.fillMaxWidth()){ Icon(Icons.Default.Equalizer,null); Spacer(Modifier.width(8.dp)); Text("Open Equalizer") }
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("Playback", color=NKColors.Cyan, style=MaterialTheme.typography.labelLarge)
        Spacer(Modifier.height(8.dp))
        GlassCard{
            Column(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(8.dp)){
                SettingRow(Icons.Default.PlayCircle, "Background playback", "Keeps audio playing with screen off & lock controls")
                SettingRow(Icons.Default.Lock, "Lock screen controls", "MediaSession + notification controls")
                SettingRow(Icons.Default.Speed, "Playback speed", "0.5x — 3x in player • remembers per session")
                SettingRow(Icons.Default.Gesture, "Gestures (video)", "Swipe vertical: brightness/volume • horizontal: seek • double-tap: 10s skip")
                SettingRow(Icons.Default.Subtitles, "Subtitles", "Auto-load .srt/.vtt next to video • picker in player")
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("Formats & Codecs", color=NKColors.Cyan, style=MaterialTheme.typography.labelLarge)
        Spacer(Modifier.height(8.dp))
        GlassCard{
            Column(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(6.dp)){
                Text("Supported via Media3/ExoPlayer + device decoders", color=NKColors.TextPri, style=MaterialTheme.typography.titleSmall)
                Text("Audio: MP3, AAC, FLAC, WAV, OGG, OPUS, M4A, WMA • Video: MP4, MKV, WEBM, MOV, AVI, 3GP, TS, HLS (.m3u8), DASH (.mpd), RTSP • Subs: SRT, VTT, SSA/ASS (via styled text)", color=NKColors.TextSec, style=MaterialTheme.typography.bodyMedium)
                Text("For widest codec coverage, LibVLC can be added (arm64 .aar) — Media3 already covers most modern files; VLC widens MKV/AC3/DTS.", color=NKColors.TextMuted, style=MaterialTheme.typography.bodyMedium)
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("About", color=NKColors.Cyan, style=MaterialTheme.typography.labelLarge)
        Spacer(Modifier.height(8.dp))
        GlassCard{ Column(Modifier.padding(16.dp)){
            Text("NK PLAYER v1.0.0", color=NKColors.TextPri, style=MaterialTheme.typography.titleMedium)
            Text("Premium all-in-one audio & video player • Built with Jetpack Compose + Media3 • Glassmorphism design system", color=NKColors.TextSec, style=MaterialTheme.typography.bodyMedium)
        } }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable private fun SettingRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String){
    Row(verticalAlignment=Alignment.Top, modifier=Modifier.fillMaxWidth()){
        Icon(icon, null, tint=NKColors.TextSec, modifier=Modifier.size(20.dp)); Spacer(Modifier.width(12.dp))
        Column{ Text(title, color=NKColors.TextPri, style=MaterialTheme.typography.titleSmall); Text(subtitle, color=NKColors.TextSec, style=MaterialTheme.typography.bodyMedium) }
    }
}
