package com.nk.player.utils

fun fmtDuration(ms: Long): String {
    if (ms <= 0) return "0:00"
    val s = ms / 1000
    val m = s / 60
    val r = s % 60
    return if (m >= 60) "%d:%02d:%02d".format(m/60, m%60, r) else "%d:%02d".format(m, r)
}
fun fmtSize(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024) return String.format("%.1f KB", kb)
    val mb = kb / 1024.0
    if (mb < 1024) return String.format("%.1f MB", mb)
    return String.format("%.2f GB", mb/1024.0)
}
