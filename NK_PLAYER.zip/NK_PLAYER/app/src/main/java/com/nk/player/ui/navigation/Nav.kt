package com.nk.player.ui.navigation

sealed class Route(val route: String){
    data object Library : Route("library")
    data object Video : Route("video")
    data object Folders : Route("folders")
    data object Playlists : Route("playlists")
    data object Settings : Route("settings")
    data object Player : Route("player")
    data object Equalizer : Route("equalizer")
}
