# NK PLAYER — Futuristic Glassmorphism Audio & Video Player

Premium all-in-one Android player built **from scratch** with Jetpack Compose + Media3 (ExoPlayer).

## Design
- **Glassmorphism** (backdrop blur 15px, 15–30% translucent glass, 1px `rgba(255,255,255,0.2)` border) verified via `ui-ux-pro-max` (`glassmorphism` active, `Vibrant & Block-based` + `Space Grotesk` typography)
- **Palette:** deep navy `#060B1A` → neon **cyan `#00F0FF`** + **violet `#7C3AED`/`#A855F7`** + pink accents, glow/blur depth
- Dark interface, customizable theme (Dark / Neon / AMOLED), premium icons, smooth 200–300ms transitions

## Features
- **Library:** audio + video, search, shuffle all, favorites (Room)
- **Video grid**, **Folders** (grouped by path), **Playlists** (create/add/remove/play)
- **Player:** Media3 ExoPlayer, HLS/DASH/RTSP, queue, next/prev, repeat/shuffle, **playback speed 0.5x–2x**
- **Subtitles:** auto-load sidecar `.srt`/`.vtt`/`.ass` next to video; styled text; size in Settings
- **Gestures (video):** vertical swipe brightness/volume hint, horizontal swipe seek, controller timeout
- **Background audio** via `MediaSessionService` + lock screen/notification controls
- **Equalizer** presets + bass/treble (AudioEffect session binding)
- **Favorites**, advanced settings

## Tech
- Kotlin, Compose Material 3, Navigation Compose, Room, DataStore, Coil, Media3 1.3.1

## Build
```bash
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

## GitHub Actions
`.github/workflows/android.yml` builds debug + release APKs and uploads artifacts on push/PR.

## Formats
Audio: MP3, AAC, FLAC, WAV, OGG, OPUS, M4A • Video: MP4, MKV, WEBM, MOV, AVI, 3GP, TS, HLS, DASH, RTSP • Subs: SRT, VTT, SSA/ASS

> For maximum niche codecs (AC3/DTS exotic MKV) swap/extend with LibVLC `.aar` — Media3 covers the vast majority.
