package com.nk.player.playback

import android.content.Intent
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.exoplayer.ExoPlayer

class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        val player: ExoPlayer = PlayerManager.ensure(this)
        session = MediaSession.Builder(this, player).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo) = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = PlayerManager.exo
        if (p != null && !p.playWhenReady) { stopSelf() }
    }

    override fun onDestroy() {
        session?.release(); session = null
        // Don't release player here — MainActivity owns lifecycle; service may restart.
        super.onDestroy()
    }
}
