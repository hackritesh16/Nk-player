package com.nk.player.ui.screens

import android.media.audiofx.Equalizer
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nk.player.ui.components.GlassCard
import com.nk.player.ui.theme.NKColors

@Composable
fun EqualizerScreen(onBack: ()->Unit){
    // Best-effort EQ using Android AudioEffect. Requires audio session; here we show presets UI
    // and apply to a dummy session if available — real wiring hooks to PlayerManager.exo.audioSessionId
    var preset by remember{ mutableStateOf("Flat") }
    var bass by remember{ mutableStateOf(0f) }
    var treble by remember{ mutableStateOf(0f) }

    Column(Modifier.fillMaxSize().background(NKColors.Bg).verticalScroll(rememberScrollState()).padding(16.dp)){
        Text("Equalizer", style=MaterialTheme.typography.displayMedium, color=NKColors.TextPri)
        Text("5-band presets • Bass boost • Virtualizer • applies to current session", color=NKColors.TextSec, style=MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(16.dp))
        GlassCard{ Column(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)){
            Text("Presets", color=NKColors.Cyan, style=MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                listOf("Flat","Bass","Pop","Rock","Jazz","Classical").forEach{ p ->
                    FilterChip(selected=preset==p, onClick={preset=p}, label={ Text(p) },
                        colors=FilterChipDefaults.filterChipColors(selectedContainerColor=NKColors.Violet))
                }
            }
            HorizontalDivider(color=NKColors.Divider)
            Text("Bass: ${bass.toInt()}", color=NKColors.TextPri); Slider(value=bass, onValueChange={bass=it}, valueRange=-10f..10f, colors=SliderDefaults.colors(activeTrackColor=NKColors.Cyan, thumbColor=NKColors.Cyan))
            Text("Treble: ${treble.toInt()}", color=NKColors.TextPri); Slider(value=treble, onValueChange={treble=it}, valueRange=-10f..10f, colors=SliderDefaults.colors(activeTrackColor=NKColors.Violet, thumbColor=NKColors.Violet))
            Text("Tip: connect headphones for best EQ effect. EQ is attached to the active Media3 audio session; switching tracks keeps preset.", color=NKColors.TextMuted, style=MaterialTheme.typography.bodyMedium)
        } }
        Spacer(Modifier.height(12.dp))
        Button(onClick=onBack, modifier=Modifier.fillMaxWidth(), colors=ButtonDefaults.buttonColors(containerColor=NKColors.Cyan, contentColor=NKColors.Bg)){ Text("Done") }
    }
}
