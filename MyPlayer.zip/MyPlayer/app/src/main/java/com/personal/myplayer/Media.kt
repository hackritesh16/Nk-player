package com.personal.myplayer

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import java.io.File

data class MediaFile(
    val id: Long,
    val uri: Uri,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val size: Long,
    val dateAdded: Long,
    val folderPath: String,
    val isVideo: Boolean,
) {
    val key: String get() = (if (isVideo) "v" else "a") + id
    val folderName: String get() = File(folderPath).name.ifEmpty { "Storage" }
}

/** Queue handed from the library screen to VideoPlayerActivity. */
object PlayQueue {
    var items: List<MediaFile> = emptyList()
    var index: Int = 0
}

fun MediaFile.toMediaItem(): MediaItem =
    MediaItem.Builder()
        .setMediaId(key)
        .setUri(uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist.ifEmpty { null })
                .setAlbumTitle(album.ifEmpty { null })
                .build()
        )
        .build()

object MediaRepo {
    fun load(ctx: Context): List<MediaFile> =
        try {
            queryVideos(ctx) + queryAudio(ctx)
        } catch (e: SecurityException) {
            emptyList()
        }

    private fun queryVideos(ctx: Context): List<MediaFile> {
        val base = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_ADDED,
            MediaStore.Video.Media.DATA,
        )
        val out = ArrayList<MediaFile>()
        ctx.contentResolver.query(base, proj, null, null, null)?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val iName = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val iDur = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            val iSize = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
            val iDate = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
            val iData = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                val path = c.getString(iData) ?: ""
                out.add(
                    MediaFile(
                        id = id,
                        uri = ContentUris.withAppendedId(base, id),
                        title = c.getString(iName) ?: "Video $id",
                        artist = "",
                        album = "",
                        durationMs = c.getLong(iDur),
                        size = c.getLong(iSize),
                        dateAdded = c.getLong(iDate),
                        folderPath = File(path).parent ?: "",
                        isVideo = true,
                    )
                )
            }
        }
        return out
    }

    private fun queryAudio(ctx: Context): List<MediaFile> {
        val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.DATA,
        )
        val sel = "${MediaStore.Audio.Media.IS_RINGTONE} = 0 AND " +
            "${MediaStore.Audio.Media.IS_NOTIFICATION} = 0 AND " +
            "${MediaStore.Audio.Media.IS_ALARM} = 0"
        val out = ArrayList<MediaFile>()
        ctx.contentResolver.query(base, proj, sel, null, null)?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val iTitle = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val iName = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
            val iArtist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val iAlbum = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val iDur = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val iSize = c.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
            val iDate = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
            val iData = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                val path = c.getString(iData) ?: ""
                out.add(
                    MediaFile(
                        id = id,
                        uri = ContentUris.withAppendedId(base, id),
                        title = c.getString(iTitle) ?: c.getString(iName) ?: "Audio $id",
                        artist = c.getString(iArtist)?.takeIf { it != "<unknown>" } ?: "",
                        album = c.getString(iAlbum)?.takeIf { it != "<unknown>" } ?: "",
                        durationMs = c.getLong(iDur),
                        size = c.getLong(iSize),
                        dateAdded = c.getLong(iDate),
                        folderPath = File(path).parent ?: "",
                        isVideo = false,
                    )
                )
            }
        }
        return out
    }
}

fun fmtTime(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0)
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) String.format("%d:%02d:%02d", h, m, s) else String.format("%d:%02d", m, s)
}
