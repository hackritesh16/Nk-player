package com.personal.myplayer

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.Player
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GlassTheme { AppRoot() }
        }
    }
}

enum class SortBy(val label: String) {
    Newest("Newest"),
    Name("A–Z"),
    Size("Largest"),
    Duration("Longest"),
}

private fun sortList(list: List<MediaFile>, s: SortBy): List<MediaFile> = when (s) {
    SortBy.Name -> list.sortedBy { it.title.lowercase() }
    SortBy.Newest -> list.sortedByDescending { it.dateAdded }
    SortBy.Size -> list.sortedByDescending { it.size }
    SortBy.Duration -> list.sortedByDescending { it.durationMs }
}

data class FolderInfo(val path: String, val name: String, val count: Int, val cover: MediaFile)

private fun mediaPermissions(): Array<String> =
    if (android.os.Build.VERSION.SDK_INT >= 33) arrayOf(
        Manifest.permission.READ_MEDIA_VIDEO,
        Manifest.permission.READ_MEDIA_AUDIO,
        Manifest.permission.POST_NOTIFICATIONS,
    ) else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

private fun hasMediaPermission(ctx: Context): Boolean {
    val p = if (android.os.Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
    else Manifest.permission.READ_EXTERNAL_STORAGE
    return ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
}

@Composable
fun AppRoot(vm: LibraryViewModel = viewModel()) {
    val ctx = LocalContext.current
    val activity = ctx as ComponentActivity
    val audio = remember { AudioController(ctx.applicationContext) }

    var granted by remember { mutableStateOf(hasMediaPermission(ctx)) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasMediaPermission(ctx)
        if (granted) vm.load()
    }
    val openFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
                // temporary grant is enough
            }
            ctx.startActivity(
                Intent(ctx, VideoPlayerActivity::class.java)
                    .setData(uri)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        }
    }

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var searching by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    var folder by rememberSaveable { mutableStateOf<String?>(null) }
    var sort by rememberSaveable { mutableStateOf(SortBy.Newest) }
    var showNow by remember { mutableStateOf(false) }
    var showUrl by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        audio.connect()
        if (granted) vm.load() else permLauncher.launch(mediaPermissions())
    }
    DisposableEffect(Unit) { onDispose { audio.release() } }
    DisposableEffect(activity) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) vm.refresh() }
        activity.lifecycle.addObserver(obs)
        onDispose { activity.lifecycle.removeObserver(obs) }
    }
    LaunchedEffect(Unit) {
        while (true) {
            audio.tick()
            delay(500)
        }
    }

    BackHandler(enabled = searching || (folder != null && tab == 0)) {
        if (searching) {
            searching = false
            query = ""
        } else {
            folder = null
        }
    }

    val q = query.trim().lowercase()
    fun match(f: MediaFile) = q.isEmpty() ||
        f.title.lowercase().contains(q) ||
        f.artist.lowercase().contains(q) ||
        f.album.lowercase().contains(q)

    val videos = vm.videos
    val audios = vm.audios
    val favItems = remember(vm.favs, videos, audios) { (videos + audios).filter { it.key in vm.favs } }
    val histItems = remember(vm.history, videos, audios) {
        val map = (videos + audios).associateBy { it.key }
        vm.history.mapNotNull { map[it] }
    }
    val currentFile = remember(audio.currentKey, audios) { vm.byKey(audio.currentKey) }

    fun open(item: MediaFile, list: List<MediaFile>) {
        if (item.isVideo) {
            val queue = list.filter { it.isVideo }
            PlayQueue.items = queue
            PlayQueue.index = queue.indexOf(item).coerceAtLeast(0)
            ctx.startActivity(Intent(ctx, VideoPlayerActivity::class.java))
        } else {
            val queue = list.filter { !it.isVideo }
            audio.play(queue, queue.indexOf(item).coerceAtLeast(0))
        }
    }

    val tabs: List<Pair<String, ImageVector>> = listOf(
        "Videos" to Icons.Filled.VideoLibrary,
        "Music" to Icons.Filled.LibraryMusic,
        "Favourites" to Icons.Filled.Favorite,
        "History" to Icons.Filled.History,
    )
    val showFolders = tab == 0 && folder == null && q.isEmpty()

    GlassBackground {
        Scaffold(
            containerColor = Color.Transparent,
            contentColor = Color.White,
            topBar = {
                Column(Modifier.statusBarsPadding()) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        if (folder != null && tab == 0) {
                            GlassIconButton(Icons.AutoMirrored.Filled.ArrowBack, "Back", { folder = null })
                        } else {
                            GlassIconButton(tabs[tab].second, tabs[tab].first, {}, strong = true)
                        }
                        Spacer(Modifier.width(12.dp))
                        if (searching) {
                            Box(
                                Modifier.weight(1f).height(44.dp).glass(RoundedCornerShape(22.dp)).padding(horizontal = 16.dp),
                                contentAlignment = Alignment.CenterStart,
                            ) {
                                if (query.isEmpty()) Text("Search", color = GlassColors.TextDim)
                                BasicTextField(
                                    value = query,
                                    onValueChange = { query = it },
                                    singleLine = true,
                                    textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                                    cursorBrush = SolidColor(Color.White),
                                    modifier = Modifier.fillMaxWidth(),
                                )
                            }
                        } else {
                            val t = if (tab == 0 && folder != null) {
                                java.io.File(folder!!).name.ifEmpty { "Videos" }
                            } else tabs[tab].first
                            Text(
                                t,
                                modifier = Modifier.weight(1f),
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        GlassIconButton(
                            if (searching) Icons.Filled.Close else Icons.Filled.Search,
                            "Search",
                            {
                                searching = !searching
                                if (!searching) query = ""
                            },
                        )
                        Spacer(Modifier.width(8.dp))
                        Box {
                            GlassIconButton(Icons.Filled.MoreVert, "More", { moreMenu = true })
                            DropdownMenu(expanded = moreMenu, onDismissRequest = { moreMenu = false }) {
                                DropdownMenuItem(
                                    text = { Text("Open any file…") },
                                    onClick = {
                                        moreMenu = false
                                        openFile.launch(arrayOf("*/*"))
                                    },
                                )
                                DropdownMenuItem(
                                    text = { Text("Play network stream") },
                                    onClick = {
                                        moreMenu = false
                                        showUrl = true
                                    },
                                )
                                DropdownMenuItem(
                                    text = { Text("Clear history") },
                                    onClick = {
                                        moreMenu = false
                                        vm.clearHistory()
                                    },
                                )
                                DropdownMenuItem(
                                    text = { Text("Rescan library") },
                                    onClick = {
                                        moreMenu = false
                                        vm.load()
                                    },
                                )
                            }
                        }
                    }
                    if (!showFolders && !searching) {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(bottom = 8.dp),
                        ) {
                            items(SortBy.entries.toList()) { s ->
                                GlassChip(s.label, sort == s) { sort = s }
                            }
                        }
                    }
                }
            },
            bottomBar = {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    if (audio.hasMedia) MiniPlayer(audio, currentFile) { showNow = true }
                    GlassNavBar(tabs, tab) {
                        tab = it
                        folder = null
                    }
                }
            },
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                when {
                    !granted -> PermissionPrompt { permLauncher.launch(mediaPermissions()) }
                    vm.loading -> CircularProgressIndicator(Modifier.align(Alignment.Center), color = Color.White)
                    else -> when (tab) {
                        0 -> {
                            if (showFolders) {
                                val folders = remember(videos) {
                                    videos.groupBy { it.folderPath }
                                        .map { (p, l) -> FolderInfo(p, l.first().folderName, l.size, l.maxByOrNull { it.dateAdded } ?: l.first()) }
                                        .sortedBy { it.name.lowercase() }
                                }
                                if (folders.isEmpty()) EmptyState("No videos found")
                                else FolderGrid(folders) { folder = it.path }
                            } else {
                                val list = sortList(
                                    videos.filter { (folder == null || it.folderPath == folder) && match(it) },
                                    sort,
                                )
                                MediaList(list, vm, audio, "No videos found") { open(it, list) }
                            }
                        }
                        1 -> {
                            val list = sortList(audios.filter { match(it) }, sort)
                            MediaList(list, vm, audio, "No music found") { open(it, list) }
                        }
                        2 -> {
                            val list = sortList(favItems.filter { match(it) }, sort)
                            MediaList(list, vm, audio, "Tap the heart on any item to add it here") { open(it, list) }
                        }
                        else -> {
                            val list = histItems.filter { match(it) }
                            MediaList(list, vm, audio, "Nothing played yet") { open(it, list) }
                        }
                    }
                }
            }
        }

        if (showNow && audio.hasMedia) {
            NowPlaying(audio, vm, currentFile) { showNow = false }
        }
    }

    if (showUrl) {
        var url by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showUrl = false },
            title = { Text("Play network stream") },
            text = {
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    singleLine = true,
                    placeholder = { Text("https://…  (.mp4 .mkv .m3u8 .mpd)") },
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val u = url.trim()
                    if (u.isNotEmpty()) {
                        showUrl = false
                        ctx.startActivity(Intent(ctx, VideoPlayerActivity::class.java).setData(Uri.parse(u)))
                    }
                }) { Text("Play") }
            },
            dismissButton = { TextButton(onClick = { showUrl = false }) { Text("Cancel") } },
        )
    }
}

@Composable
fun EmptyState(text: String) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(text, color = GlassColors.TextDim, textAlign = TextAlign.Center)
    }
}

@Composable
fun PermissionPrompt(onGrant: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("MyPlayer needs access to your videos and music to build the library.", textAlign = TextAlign.Center)
        Spacer(Modifier.height(16.dp))
        Button(onClick = onGrant) { Text("Allow access") }
    }
}

/** Folder tiles with the latest video frame as cover, like the collection cards in the reference. */
@Composable
fun FolderGrid(folders: List<FolderInfo>, onClick: (FolderInfo) -> Unit) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        gridItems(folders, key = { it.path }) { f ->
            val shape = RoundedCornerShape(22.dp)
            Box(
                Modifier
                    .fillMaxWidth()
                    .aspectRatio(0.92f)
                    .clip(shape)
                    .border(1.dp, Color.White.copy(alpha = 0.25f), shape)
                    .clickable { onClick(f) }
            ) {
                Thumb(f.cover, Modifier.fillMaxSize(), 400, shape = shape, iconSize = 40.dp)
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC0B0820)))
                    )
                )
                Column(Modifier.align(Alignment.BottomStart).padding(14.dp)) {
                    Text(
                        f.name,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        "${f.count} video" + if (f.count == 1) "" else "s",
                        style = MaterialTheme.typography.bodySmall,
                        color = GlassColors.TextDim,
                    )
                }
            }
        }
    }
}

@Composable
fun MediaList(
    list: List<MediaFile>,
    vm: LibraryViewModel,
    audio: AudioController,
    empty: String,
    onOpen: (MediaFile) -> Unit,
) {
    if (list.isEmpty()) {
        EmptyState(empty)
        return
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 8.dp)) {
        items(list, key = { it.key }) { f ->
            val pos = remember(vm.tick, f.key) { Prefs.getPos(f.key) }
            val progress = if (pos > 0 && f.durationMs > 0) (pos.toFloat() / f.durationMs).coerceIn(0f, 1f) else 0f
            val current = audio.currentKey == f.key
            MediaRow(
                f = f,
                fav = f.key in vm.favs,
                progress = progress,
                current = current,
                playingNow = current && audio.isPlaying,
                onClick = { onOpen(f) },
                onFav = { vm.toggleFav(f) },
            )
        }
    }
}

@Composable
fun MediaRow(
    f: MediaFile,
    fav: Boolean,
    progress: Float,
    current: Boolean,
    playingNow: Boolean,
    onClick: () -> Unit,
    onFav: () -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (f.isVideo) Thumb(f, Modifier.size(width = 96.dp, height = 56.dp), 240)
        else Thumb(f, Modifier.size(56.dp), 160)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                f.title,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontWeight = FontWeight.Medium,
                color = if (current) GlassColors.VioletSoft else Color.White,
            )
            val sub = buildString {
                if (!f.isVideo && f.artist.isNotEmpty()) append(f.artist).append("  •  ")
                append(fmtTime(f.durationMs))
                if (f.isVideo) append("  •  ").append(fmtSize(f.size))
            }
            Text(
                sub,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall,
                color = GlassColors.TextDim,
            )
            if (progress > 0f) {
                LinearProgressIndicator(
                    progress = { progress },
                    color = GlassColors.VioletSoft,
                    trackColor = Color.White.copy(alpha = 0.2f),
                    modifier = Modifier.fillMaxWidth().padding(top = 5.dp).height(3.dp),
                )
            }
        }
        IconButton(onClick = onFav, modifier = Modifier.size(40.dp)) {
            Icon(
                if (fav) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                "Favourite",
                tint = if (fav) GlassColors.Pink else GlassColors.TextDim,
                modifier = Modifier.size(20.dp),
            )
        }
        GlassIconButton(
            if (playingNow) Icons.Filled.Pause else Icons.Filled.PlayArrow,
            "Play",
            onClick,
            size = 42.dp,
            active = current,
        )
    }
}

private fun fmtSize(bytes: Long): String = when {
    bytes >= 1L shl 30 -> String.format("%.1f GB", bytes / (1024.0 * 1024.0 * 1024.0))
    bytes >= 1L shl 20 -> String.format("%.0f MB", bytes / (1024.0 * 1024.0))
    else -> String.format("%.0f KB", bytes / 1024.0)
}

/** Floating glass mini player (progress ring around play/pause, like the reference). */
@Composable
fun MiniPlayer(audio: AudioController, file: MediaFile?, onClick: () -> Unit) {
    val frac = if (audio.durationMs > 0) audio.positionMs.toFloat() / audio.durationMs else 0f
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .glass(RoundedCornerShape(32.dp), strong = true)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(50.dp), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(
                progress = { frac.coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxSize(),
                color = GlassColors.Pink,
                trackColor = Color.White.copy(alpha = 0.22f),
                strokeWidth = 3.dp,
            )
            IconButton(onClick = { audio.togglePlay() }, modifier = Modifier.size(42.dp)) {
                Icon(
                    if (audio.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    "Play or pause",
                    tint = Color.White,
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                audio.title,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontWeight = FontWeight.SemiBold,
                style = MaterialTheme.typography.bodyMedium,
            )
            if (audio.artist.isNotEmpty()) {
                Text(
                    audio.artist,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall,
                    color = GlassColors.TextDim,
                )
            }
        }
        GlassIconButton(Icons.Filled.SkipNext, "Next", { audio.next() }, size = 38.dp, iconSize = 20.dp)
        Spacer(Modifier.width(6.dp))
        GlassIconButton(Icons.Filled.Close, "Stop", { audio.close() }, size = 38.dp, iconSize = 18.dp)
    }
}

@Composable
fun NowPlaying(audio: AudioController, vm: LibraryViewModel, file: MediaFile?, onClose: () -> Unit) {
    BackHandler(onBack = onClose)
    var drag by remember { mutableStateOf<Float?>(null) }
    var sleepMenu by remember { mutableStateOf(false) }
    val speeds = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)

    GlassBackground {
        Column(
            Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 24.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                GlassIconButton(Icons.Filled.KeyboardArrowDown, "Close", onClose)
                Text(
                    "Now Playing",
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    fontWeight = FontWeight.Medium,
                )
                if (file != null) {
                    val fav = file.key in vm.favs
                    GlassIconButton(
                        if (fav) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                        "Favourite",
                        { vm.toggleFav(file) },
                    )
                } else {
                    Spacer(Modifier.size(44.dp))
                }
            }
            Spacer(Modifier.weight(1f))
            Thumb(
                file,
                Modifier
                    .size(264.dp)
                    .shadow(28.dp, CircleShape, ambientColor = GlassColors.Violet, spotColor = GlassColors.Violet)
                    .border(2.dp, Color.White.copy(alpha = 0.28f), CircleShape),
                600,
                shape = CircleShape,
                iconSize = 72.dp,
            )
            Spacer(Modifier.height(28.dp))
            Text(
                audio.title,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.SemiBold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
            )
            if (audio.artist.isNotEmpty()) {
                Spacer(Modifier.height(4.dp))
                Text(
                    audio.artist,
                    color = GlassColors.TextDim,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Spacer(Modifier.weight(1f))

            val dur = audio.durationMs.coerceAtLeast(1L).toFloat()
            val progress = drag ?: (audio.positionMs.toFloat() / dur).coerceIn(0f, 1f)
            WaveformSeekBar(
                progress = progress,
                seed = audio.currentKey.ifEmpty { audio.title },
                onSeek = { drag = it },
                onSeekDone = {
                    drag?.let { audio.seekTo((it * dur).toLong()) }
                    drag = null
                },
                modifier = Modifier.fillMaxWidth().height(56.dp),
            )
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth()) {
                Text(fmtTime((progress * dur).toLong()), style = MaterialTheme.typography.bodySmall, color = GlassColors.TextDim)
                Spacer(Modifier.weight(1f))
                Text(fmtTime(audio.durationMs), style = MaterialTheme.typography.bodySmall, color = GlassColors.TextDim)
            }
            Spacer(Modifier.height(20.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                GlassIconButton(Icons.Filled.Shuffle, "Shuffle", { audio.toggleShuffle() }, active = audio.shuffle)
                GlassIconButton(Icons.Filled.SkipPrevious, "Previous", { audio.previous() }, size = 52.dp, iconSize = 28.dp)
                GlassIconButton(
                    if (audio.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    "Play or pause",
                    { audio.togglePlay() },
                    size = 78.dp,
                    iconSize = 40.dp,
                    strong = true,
                )
                GlassIconButton(Icons.Filled.SkipNext, "Next", { audio.next() }, size = 52.dp, iconSize = 28.dp)
                GlassIconButton(
                    if (audio.repeatMode == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                    "Repeat",
                    { audio.cycleRepeat() },
                    active = audio.repeatMode != Player.REPEAT_MODE_OFF,
                )
            }
            Spacer(Modifier.height(20.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                GlassChip("Speed ${audio.speed}x", false) {
                    val i = speeds.indexOfFirst { it >= audio.speed - 0.001f }
                    audio.changeSpeed(speeds[((if (i < 0) 0 else i) + 1) % speeds.size])
                }
                Box {
                    val left = if (audio.sleepEndsAt > 0) {
                        ((audio.sleepEndsAt - System.currentTimeMillis()) / 60_000L + 1).coerceAtLeast(1L)
                    } else 0L
                    GlassChip(if (left > 0) "Sleep in $left min" else "Sleep timer", left > 0) { sleepMenu = true }
                    DropdownMenu(expanded = sleepMenu, onDismissRequest = { sleepMenu = false }) {
                        listOf(0, 15, 30, 45, 60, 90).forEach { m ->
                            DropdownMenuItem(
                                text = { Text(if (m == 0) "Off" else "$m minutes") },
                                onClick = {
                                    audio.setSleepTimer(m)
                                    sleepMenu = false
                                },
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}
