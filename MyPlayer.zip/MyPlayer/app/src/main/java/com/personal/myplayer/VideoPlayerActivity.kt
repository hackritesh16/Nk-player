package com.personal.myplayer

import android.app.PictureInPictureParams
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.util.Rational
import android.util.TypedValue
import android.view.Gravity
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.DefaultTimeBar
import androidx.media3.ui.PlayerView
import androidx.media3.ui.PlayerView.SHOW_BUFFERING_WHEN_PLAYING
import io.github.anilbeesetti.nextlib.media3ext.ffdecoder.NextRenderersFactory
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Full-screen player for video (and any audio file opened from outside / "Open any file").
 * Gestures: swipe left side = brightness, right side = volume, horizontal swipe = seek,
 * double tap left/right = -/+10s, double tap centre = play/pause, long press = 2x speed.
 */
class VideoPlayerActivity : ComponentActivity() {

    private lateinit var exo: ExoPlayer
    private lateinit var playerView: PlayerView
    private lateinit var infoView: TextView
    private lateinit var titleView: TextView
    private lateinit var topBar: LinearLayout
    private lateinit var speedBtn: Button
    private lateinit var aspectBtn: Button
    private lateinit var audioManager: AudioManager

    private val speeds = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f, 3f, 4f)
    private var speedIdx = 2
    private val resizeModes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_FILL,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
    )
    private val resizeNames = arrayOf("Fit", "Stretch", "Zoom")
    private var resizeIdx = 0
    private val orientations = intArrayOf(
        ActivityInfo.SCREEN_ORIENTATION_SENSOR,
        ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE,
        ActivityInfo.SCREEN_ORIENTATION_PORTRAIT,
    )
    private var orientationIdx = 0
    private var orientationAutoSet = false

    private var curKey = ""
    private var inPip = false

    private enum class Mode { NONE, VOLUME, BRIGHTNESS, SEEK }

    private var mode = Mode.NONE
    private var seekStartPos = 0L
    private var seekTarget = 0L
    private var startVolume = 0f
    private var startBrightness = 0.5f
    private var longPressed = false
    private val hideInfo = Runnable { infoView.visibility = View.GONE }

    private val pickSubtitle =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) addSubtitle(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager

        val renderers = NextRenderersFactory(this)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
        exo = ExoPlayer.Builder(this, renderers)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .build()

        buildUi()
        exo.addListener(playerListener)
        addOnPictureInPictureModeChangedListener { info ->
            inPip = info.isInPictureInPictureMode
            playerView.useController = !inPip
            topBar.visibility = if (inPip) View.GONE else topBar.visibility
        }
        loadMedia()
    }

    // ---------------------------------------------------------------- UI

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    /** Frosted-glass look: translucent white fill with a light edge. */
    private fun glassDrawable(radiusDp: Int, fillAlpha: Int): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(radiusDp).toFloat()
            setColor((fillAlpha shl 24) or 0xFFFFFF)
            setStroke(dp(1), 0x55FFFFFF)
        }

    private fun barButton(label: String, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = glassDrawable(18, 0x26)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            minWidth = 0
            minimumWidth = 0
            minHeight = 0
            minimumHeight = 0
            stateListAnimator = null
            setPadding(dp(12), 0, dp(12), 0)
            setOnClickListener { onClick() }
        }

    private fun addBarButton(b: Button) {
        topBar.addView(
            b,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(36)).apply {
                setMargins(dp(3), 0, dp(3), 0)
            }
        )
    }

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        playerView = PlayerView(this).apply {
            player = exo
            setShowSubtitleButton(true)
            setRepeatToggleModes(
                androidx.media3.common.util.RepeatModeUtil.REPEAT_TOGGLE_MODE_ONE or
                    androidx.media3.common.util.RepeatModeUtil.REPEAT_TOGGLE_MODE_ALL
            )
            setShowBuffering(SHOW_BUFFERING_WHEN_PLAYING)
            controllerShowTimeoutMs = 3500
            setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { v ->
                if (!inPip) topBar.visibility = v
            })
        }
        root.addView(playerView, FrameLayout.LayoutParams(-1, -1))
        playerView.findViewById<DefaultTimeBar>(androidx.media3.ui.R.id.exo_progress)?.apply {
            setPlayedColor(0xFFC58BFF.toInt())
            setScrubberColor(0xFFFFFFFF.toInt())
            setBufferedColor(0x55FFFFFF)
            setUnplayedColor(0x33FFFFFF)
        }

        infoView = TextView(this).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            typeface = Typeface.DEFAULT_BOLD
            background = glassDrawable(24, 0x55)
            setPadding(dp(20), dp(10), dp(20), dp(10))
            gravity = Gravity.CENTER
            visibility = View.GONE
        }
        root.addView(
            infoView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER)
        )

        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = glassDrawable(28, 0x33)
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        titleView = TextView(this).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        speedBtn = barButton("1x") { cycleSpeed() }
        aspectBtn = barButton("Fit") { cycleAspect() }
        addBarButton(barButton("←") { finish() })
        topBar.addView(
            titleView,
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                setMargins(dp(8), 0, dp(8), 0)
            }
        )
        addBarButton(speedBtn)
        addBarButton(aspectBtn)
        addBarButton(barButton("Rotate") { cycleOrientation() })
        addBarButton(barButton("Sub+") { pickSubtitle.launch(arrayOf("*/*")) })
        addBarButton(barButton("PiP") { enterPip() })
        root.addView(
            topBar,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP).apply {
                setMargins(dp(12), dp(12), dp(12), 0)
            }
        )

        setContentView(root)
        setupGestures()
        hideSystemBars()
    }

    private fun hideSystemBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.hide(WindowInsetsCompat.Type.systemBars())
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    private fun showInfo(text: String) {
        infoView.text = text
        infoView.visibility = View.VISIBLE
        infoView.removeCallbacks(hideInfo)
        infoView.postDelayed(hideInfo, 900)
    }

    // ---------------------------------------------------------------- gestures

    private fun currentBrightness(): Float {
        val b = window.attributes.screenBrightness
        if (b >= 0f) return b
        return try {
            Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
        } catch (e: Exception) {
            0.5f
        }
    }

    private fun setupGestures() {
        val slop = android.view.ViewConfiguration.get(this).scaledTouchSlop
        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean {
                mode = Mode.NONE
                return true
            }

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (playerView.isControllerFullyVisible) playerView.hideController() else playerView.showController()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                val w = playerView.width.toFloat()
                when {
                    e.x < w / 3f -> seekBy(-10_000L)
                    e.x > w * 2f / 3f -> seekBy(10_000L)
                    else -> togglePlay()
                }
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                longPressed = true
                exo.setPlaybackSpeed(2f)
                showInfo("2x")
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
                if (e1 == null || longPressed) return false
                val dx = e2.x - e1.x
                val dy = e2.y - e1.y
                val w = playerView.width.toFloat().coerceAtLeast(1f)
                val h = playerView.height.toFloat().coerceAtLeast(1f)
                if (mode == Mode.NONE) {
                    if (abs(dx) < slop && abs(dy) < slop) return false
                    mode = if (abs(dx) > abs(dy)) {
                        seekStartPos = exo.currentPosition
                        Mode.SEEK
                    } else if (e1.x < w / 2f) {
                        startBrightness = currentBrightness()
                        Mode.BRIGHTNESS
                    } else {
                        startVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()
                        Mode.VOLUME
                    }
                }
                when (mode) {
                    Mode.SEEK -> {
                        val dur = exo.duration.coerceAtLeast(0L)
                        val delta = (dx / w * 120_000f).toLong()
                        seekTarget = (seekStartPos + delta).coerceIn(0L, if (dur > 0) dur else Long.MAX_VALUE)
                        val sign = if (delta >= 0) "+" else "-"
                        showInfo("${fmtTime(seekTarget)}  ($sign${abs(delta) / 1000}s)")
                    }
                    Mode.BRIGHTNESS -> {
                        val v = (startBrightness - dy / h * 1.2f).coerceIn(0.02f, 1f)
                        val lp = window.attributes
                        lp.screenBrightness = v
                        window.attributes = lp
                        showInfo("Brightness ${(v * 100).roundToInt()}%")
                    }
                    Mode.VOLUME -> {
                        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                        val v = (startVolume - dy / h * max * 1.2f).coerceIn(0f, max.toFloat())
                        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, v.roundToInt(), 0)
                        showInfo("Volume ${(v / max * 100).roundToInt()}%")
                    }
                    else -> {}
                }
                return true
            }
        })

        playerView.setOnTouchListener { _, ev ->
            detector.onTouchEvent(ev)
            if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                if (mode == Mode.SEEK && ev.actionMasked == MotionEvent.ACTION_UP) exo.seekTo(seekTarget)
                if (longPressed) {
                    exo.setPlaybackSpeed(speeds[speedIdx])
                    longPressed = false
                }
                mode = Mode.NONE
            }
            true
        }
    }

    private fun seekBy(ms: Long) {
        val dur = exo.duration
        val target = (exo.currentPosition + ms).coerceAtLeast(0L)
        exo.seekTo(if (dur > 0) target.coerceAtMost(dur) else target)
        showInfo(if (ms > 0) "+${ms / 1000}s" else "${ms / 1000}s")
    }

    private fun togglePlay() {
        if (exo.isPlaying) exo.pause() else exo.play()
    }

    // ---------------------------------------------------------------- top bar actions

    private fun speedLabel(s: Float): String =
        if (s == s.toInt().toFloat()) "${s.toInt()}x" else "${s}x"

    private fun cycleSpeed() {
        speedIdx = (speedIdx + 1) % speeds.size
        exo.setPlaybackSpeed(speeds[speedIdx])
        speedBtn.text = speedLabel(speeds[speedIdx])
        showInfo(speedLabel(speeds[speedIdx]))
    }

    private fun cycleAspect() {
        resizeIdx = (resizeIdx + 1) % resizeModes.size
        playerView.resizeMode = resizeModes[resizeIdx]
        aspectBtn.text = resizeNames[resizeIdx]
        showInfo(resizeNames[resizeIdx])
    }

    private fun cycleOrientation() {
        orientationIdx = (orientationIdx + 1) % orientations.size
        requestedOrientation = orientations[orientationIdx]
        showInfo(arrayOf("Auto rotate", "Landscape", "Portrait")[orientationIdx])
    }

    private fun enterPip() {
        if (!packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) return
        try {
            val vs = exo.videoSize
            val r = if (vs.width > 0 && vs.height > 0) vs.width.toFloat() / vs.height else 16f / 9f
            val ratio = Rational((r.coerceIn(0.5f, 2.3f) * 1000).toInt(), 1000)
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(ratio).build())
        } catch (e: Exception) {
            Toast.makeText(this, "Picture-in-picture not available", Toast.LENGTH_SHORT).show()
        }
    }

    private fun displayName(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val n = c.getString(0)
                    if (!n.isNullOrEmpty()) return n
                }
            }
        } catch (e: Exception) {
            // fall through
        }
        return uri.lastPathSegment ?: uri.toString()
    }

    private fun addSubtitle(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) {
            // temporary grant is fine
        }
        val cur = exo.currentMediaItem ?: return
        val name = displayName(uri).lowercase()
        val mime = when {
            name.endsWith(".vtt") -> MimeTypes.TEXT_VTT
            name.endsWith(".ass") || name.endsWith(".ssa") -> MimeTypes.TEXT_SSA
            name.endsWith(".ttml") || name.endsWith(".xml") || name.endsWith(".dfxp") -> MimeTypes.APPLICATION_TTML
            else -> MimeTypes.APPLICATION_SUBRIP
        }
        val sub = MediaItem.SubtitleConfiguration.Builder(uri)
            .setMimeType(mime)
            .setLanguage("und")
            .setLabel(displayName(uri))
            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
            .build()
        val newItem = cur.buildUpon().setSubtitleConfigurations(listOf(sub)).build()
        val idx = exo.currentMediaItemIndex
        val pos = exo.currentPosition
        exo.replaceMediaItem(idx, newItem)
        exo.seekTo(idx, pos)
        showInfo("Subtitle added")
    }

    // ---------------------------------------------------------------- media loading

    private fun loadMedia() {
        val data = intent?.data
        val items: List<MediaItem>
        var startIndex = 0
        var startPos = C.TIME_UNSET

        if (data != null) {
            items = listOf(
                MediaItem.Builder()
                    .setUri(data)
                    .setMediaMetadata(MediaMetadata.Builder().setTitle(displayName(data)).build())
                    .build()
            )
        } else {
            val q = PlayQueue.items
            items = q.map { it.toMediaItem() }
            startIndex = PlayQueue.index.coerceIn(0, (items.size - 1).coerceAtLeast(0))
            val f = q.getOrNull(startIndex)
            if (f != null) {
                val saved = Prefs.getPos(f.key)
                if (saved > 3_000 && (f.durationMs <= 0 || f.durationMs - saved > 5_000)) startPos = saved
            }
        }

        if (items.isEmpty()) {
            finish()
            return
        }
        exo.setMediaItems(items, startIndex, startPos)
        exo.prepare()
        exo.playWhenReady = true
    }

    private val playerListener = object : Player.Listener {
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            curKey = mediaItem?.mediaId.orEmpty()
            if (curKey.isNotEmpty()) Prefs.addHistory(curKey)
            titleView.text = mediaItem?.mediaMetadata?.title ?: ""
        }

        override fun onPositionDiscontinuity(
            oldPosition: Player.PositionInfo,
            newPosition: Player.PositionInfo,
            reason: Int
        ) {
            val oldId = oldPosition.mediaItem?.mediaId.orEmpty()
            val newId = newPosition.mediaItem?.mediaId.orEmpty()
            if (oldId.isNotEmpty() && oldId != newId) {
                Prefs.setPos(
                    oldId,
                    if (reason == Player.DISCONTINUITY_REASON_AUTO_TRANSITION) 0L else oldPosition.positionMs
                )
            }
        }

        override fun onPlaybackStateChanged(state: Int) {
            if (state == Player.STATE_ENDED && curKey.isNotEmpty()) Prefs.setPos(curKey, 0L)
        }

        override fun onVideoSizeChanged(videoSize: VideoSize) {
            if (!orientationAutoSet && videoSize.width > 0 && videoSize.height > 0) {
                orientationAutoSet = true
                requestedOrientation = if (videoSize.width >= videoSize.height)
                    ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                else
                    ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            Toast.makeText(
                this@VideoPlayerActivity,
                "Can't play this file (${error.errorCodeName})",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    // ---------------------------------------------------------------- lifecycle

    private fun saveProgress() {
        if (curKey.isNotEmpty()) Prefs.savePos(curKey, exo.currentPosition, exo.duration)
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (exo.isPlaying) enterPip()
    }

    override fun onPause() {
        super.onPause()
        saveProgress()
    }

    override fun onStop() {
        super.onStop()
        saveProgress()
        if (isInPictureInPictureMode) {
            // PiP window was closed by the user
            exo.pause()
            finish()
        } else {
            exo.pause()
        }
    }

    override fun onDestroy() {
        saveProgress()
        infoView.removeCallbacks(hideInfo)
        exo.release()
        super.onDestroy()
    }
}
