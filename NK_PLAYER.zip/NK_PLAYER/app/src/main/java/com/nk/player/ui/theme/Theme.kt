package com.nk.player.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// NK PLAYER — Futuristic Glassmorphism: neon cyan + violet on deep navy
// Verified via ui-ux-pro-max: glassmorphism (backdrop blur 15px, 15–30% glass, vibrant BG) + typography Orbitron/Exo2 + Space Grotesk fallback
object NKColors {
    val Bg         = Color(0xFF060B1A)
    val Bg2        = Color(0xFF0A1430)
    val BgCard     = Color(0xFF0F1D3A)
    val Cyan       = Color(0xFF00F0FF)
    val CyanSoft   = Color(0xFF33F2FF)
    val Violet     = Color(0xFF7C3AED)
    val Purple     = Color(0xFFA855F7)
    val Pink       = Color(0xFFEC4899)
    val Lime       = Color(0xFF22F5B0)
    val Glass      = Color(0x1AFFFFFF)
    val GlassBorder= Color(0x33FFFFFF)
    val GlassStrong= Color(0x2AFFFFFF)
    val TextPri    = Color(0xFFF1F5FF)
    val TextSec    = Color(0xFF8EA0C6)
    val TextMuted  = Color(0xFF5B6B8A)
    val Divider    = Color(0x1FFFFFFF)
}

private val NkDarkScheme = darkColorScheme(
    primary = NKColors.Cyan,
    onPrimary = NKColors.Bg,
    primaryContainer = Color(0xFF003A42),
    secondary = NKColors.Violet,
    onSecondary = Color.White,
    tertiary = NKColors.Pink,
    background = NKColors.Bg,
    onBackground = NKColors.TextPri,
    surface = NKColors.Bg2,
    onSurface = NKColors.TextPri,
    surfaceVariant = NKColors.BgCard,
    onSurfaceVariant = NKColors.TextSec,
    outline = NKColors.GlassBorder,
    outlineVariant = NKColors.Divider,
    error = Color(0xFFFF4B6E),
    scrim = Color(0x99060B1A)
)

@Composable
fun NKPlayerTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = NkDarkScheme, typography = NkTypography, content = content)
}
