package com.nk.player.utils

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.ds by preferencesDataStore("nk_prefs")

object Prefs {
    private lateinit var app: Context
    fun init(c: Context){ app = c.applicationContext }

    private val THEME = stringPreferencesKey("theme") // dark | neon | amoled
    private val SPEED = floatPreferencesKey("speed")
    private val REPEAT = stringPreferencesKey("repeat") // off | one | all
    private val SHUFFLE = booleanPreferencesKey("shuffle")
    private val SLEEP = longPreferencesKey("sleep_ms")
    private val EQ = stringPreferencesKey("eq_preset")

    val theme: Flow<String> = app.dataStore.data.map { it[THEME] ?: "dark" }
    val speed: Flow<Float> = app.dataStore.data.map { it[SPEED] ?: 1f }
    val repeat: Flow<String> = app.dataStore.data.map { it[REPEAT] ?: "off" }
    val shuffle: Flow<Boolean> = app.dataStore.data.map { it[SHUFFLE] ?: false }
    val eqPreset: Flow<String> = app.dataStore.data.map { it[EQ] ?: "Flat" }

    suspend fun setTheme(v: String){ app.dataStore.edit{ it[THEME]=v } }
    suspend fun setSpeed(v: Float){ app.dataStore.edit{ it[SPEED]=v } }
    suspend fun setRepeat(v: String){ app.dataStore.edit{ it[REPEAT]=v } }
    suspend fun setShuffle(v: Boolean){ app.dataStore.edit{ it[SHUFFLE]=v } }
    suspend fun setEq(v: String){ app.dataStore.edit{ it[EQ]=v } }

    // Non-flow snapshot helpers (for playback service quick reads)
    suspend fun snapshotTheme(): String = theme.let{ var r="dark"; app.dataStore.data.map{it[THEME]?: "dark"}.collect{ r=it }; r }
}
