package com.nk.player

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem as ExoMediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.navigation.compose.*
import com.google.accompanist.permissions.*
import com.nk.player.data.model.MediaItem
import com.nk.player.data.repo.*
import com.nk.player.playback.PlayerManager
import com.nk.player.ui.navigation.Route
import com.nk.player.ui.screens.*
import com.nk.player.ui.theme.NKColors
import com.nk.player.ui.theme.NKPlayerTheme
import com.nk.player.utils.Prefs
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private var exo: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        exo = PlayerManager.ensure(this)

        setContent {
            NKPlayerTheme {
                val nav = rememberNavController()
                var audio by remember{ mutableStateOf<List<MediaItem>>(emptyList()) }
                var video by remember{ mutableStateOf<List<MediaItem>>(emptyList()) }
                var query by remember{ mutableStateOf("") }
                var favUris by remember{ mutableStateOf<Set<String>>(emptySet()) }
                var playlists by remember{ mutableStateOf<List<PlaylistEntity>>(emptyList()) }
                var favs by remember{ mutableStateOf<List<FavoriteEntity>>(emptyList()) }
                var theme by remember{ mutableStateOf("dark") }
                var subScale by remember{ mutableStateOf(1f) }
                var speed by remember{ mutableStateOf(1f) }
                var queue by remember{ mutableStateOf<List<MediaItem>>(emptyList()) }
                var currentIndex by remember{ mutableStateOf(0) }
                var subtitleNote by remember{ mutableStateOf<String?>(null) }

                val dao = remember{ NKDatabase.get(this).dao() }

                // Load media
                LaunchedEffect(Unit){
                    audio = MediaRepository.loadAudio(this@MainActivity)
                    video = MediaRepository.loadVideo(this@MainActivity)
                }
                LaunchedEffect(Unit){
                    dao.playlists().collect{ playlists = it }
                }
                LaunchedEffect(Unit){
                    dao.favorites().collect{ favs = it; favUris = it.map{ e-> e.mediaUri }.toSet() }
                }

                // Permissions
                val perm = if(Build.VERSION.SDK_INT>=33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
                val perm2 = if(Build.VERSION.SDK_INT>=33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE
                val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()){ _ ->
                    lifecycleScope.launch{
                        audio = MediaRepository.loadAudio(this@MainActivity)
                        video = MediaRepository.loadVideo(this@MainActivity)
                    }
                }
                LaunchedEffect(Unit){ launcher.launch(arrayOf(perm, perm2)) }

                // Helpers to play
                fun playList(list: List<MediaItem>, idx: Int){
                    if(list.isEmpty()) return
                    queue = list; currentIndex = idx.coerceIn(0, list.size-1)
                    val exoItems = list.map{ m ->
                        val b = ExoMediaItem.Builder().setUri(m.uri).setMediaMetadata(
                            androidx.media3.common.MediaMetadata.Builder().setTitle(m.title).setArtist(m.artist).build()
                        )
                        // sidecar subs: .srt/.vtt alongside file
                        val sub = findSidecarSubtitle(m.path)
                        if(sub!=null){
                            val mime = if(sub.endsWith(".vtt", true)) "text/vtt" else "application/x-subrip"
                            val subCfg = ExoMediaItem.SubtitleConfiguration.Builder(android.net.Uri.parse("file://$sub")).setMimeType(mime).setLanguage("en").setSelectionFlags(1).build()
                            b.setSubtitleConfigurations(listOf(subCfg))
                            subtitleNote = sub.substringAfterLast("/")
                        } else subtitleNote = null
                        b.build()
                    }
                    exo?.let{ PlayerManager.setQueue(it, exoItems, currentIndex) }
                    exo?.playbackParameters = androidx.media3.common.PlaybackParameters(speed)
                    nav.navigate(Route.Player.route)
                }
                fun playUris(uris: List<String>, idx: Int){
                    val list = uris.mapNotNull{ u ->
                        val found = (audio+video).find{ it.uri.toString()==u }
                        found ?: MediaItem(0, android.net.Uri.parse(u), u.substringAfterLast("/"), null, null, 0, false, u, null, 0, 0)
                    }
                    playList(list, idx)
                }

                Scaffold(
                    bottomBar = {
                        val currentRoute = nav.currentBackStackEntryAsState().value?.destination?.route
                        if(currentRoute != Route.Player.route && currentRoute != Route.Equalizer.route){
                            NavigationBar(containerColor = NKColors.Bg2, contentColor = NKColors.TextPri){
                                NavigationBarItem(selected = currentRoute==Route.Library.route, onClick={ nav.navigate(Route.Library.route){ launchSingleTop=true } }, icon={ Icon(Icons.Default.LibraryMusic,null) }, label={ Text("Library") })
                                NavigationBarItem(selected = currentRoute==Route.Video.route, onClick={ nav.navigate(Route.Video.route){ launchSingleTop=true } }, icon={ Icon(Icons.Default.Videocam,null) }, label={ Text("Video") })
                                NavigationBarItem(selected = currentRoute==Route.Folders.route, onClick={ nav.navigate(Route.Folders.route){ launchSingleTop=true } }, icon={ Icon(Icons.Default.Folder,null) }, label={ Text("Folders") })
                                NavigationBarItem(selected = currentRoute==Route.Playlists.route, onClick={ nav.navigate(Route.Playlists.route){ launchSingleTop=true } }, icon={ Icon(Icons.Default.QueueMusic,null) }, label={ Text("Lists") })
                                NavigationBarItem(selected = currentRoute==Route.Settings.route, onClick={ nav.navigate(Route.Settings.route){ launchSingleTop=true } }, icon={ Icon(Icons.Default.Settings,null) }, label={ Text("Settings") })
                            }
                        }
                    },
                    containerColor = NKColors.Bg
                ){ pad ->
                    Box(Modifier.padding(pad).background(NKColors.Bg).fillMaxSize()){
                        NavHost(navController = nav, startDestination = Route.Library.route){
                            composable(Route.Library.route){
                                LibraryScreen(
                                    audio = audio, video = video, query = query, onQuery = {query=it},
                                    onPlay = { list, idx -> playList(list, idx) },
                                    onShuffleAll = { val all=(audio+video).shuffled(); if(all.isNotEmpty()) playList(all,0) },
                                    onToggleFav = { m ->
                                        lifecycleScope.launch{
                                            val uri = m.uri.toString()
                                            if(favUris.contains(uri)) dao.unfav(uri) else dao.fav(FavoriteEntity(uri, m.title))
                                        }
                                    },
                                    favUris = favUris
                                )
                            }
                            composable(Route.Video.route){ VideoScreen(videos = video, onPlay = { list, idx -> playList(list, idx) }) }
                            composable(Route.Folders.route){ FoldersScreen(all = audio+video, onPlay = { list, idx -> playList(list, idx) }) }
                            composable(Route.Playlists.route){ PlaylistsScreen(all = audio+video, playlists = playlists, favs = favs, onPlayUris = { uris, idx -> playUris(uris, idx) }, dao = dao) }
                            composable(Route.Settings.route){
                                SettingsScreen(theme = theme, onTheme = { theme = it; lifecycleScope.launch{ Prefs.setTheme(it) } },
                                    onOpenEqualizer = { nav.navigate(Route.Equalizer.route) }, subtitlesScale = subScale, onSubtitlesScale = { subScale = it })
                            }
                            composable(Route.Equalizer.route){ EqualizerScreen(onBack = { nav.popBackStack() }) }
                            composable(Route.Player.route){
                                val cur = queue.getOrNull(currentIndex)
                                PlayerScreen(
                                    player = exo,
                                    title = cur?.title ?: "Nothing playing",
                                    artist = cur?.artist,
                                    isVideo = cur?.isVideo ?: false,
                                    onBack = { nav.popBackStack() },
                                    onNext = { exo?.seekToNext(); currentIndex = (exo?.currentMediaItemIndex ?: currentIndex) },
                                    onPrev = { exo?.seekToPrevious(); currentIndex = (exo?.currentMediaItemIndex ?: currentIndex) },
                                    speed = speed,
                                    onSpeed = { s -> speed = s; exo?.playbackParameters = androidx.media3.common.PlaybackParameters(s) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    private fun findSidecarSubtitle(path: String): String? {
        if(path.isBlank()) return null
        val base = path.substringBeforeLast(".")
        val cand = listOf("$base.srt","$base.vtt","$base.ass","$base.ssa")
        for(c in cand){ try{ if(java.io.File(c).exists()) return c } catch(_: Exception){} }
        return null
    }

    override fun onDestroy() {
        // Keep service alive for background audio; only release if fully finishing
        if(isFinishing) PlayerManager.release()
        super.onDestroy()
    }
}
