package com.personal.myplayer

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Colour tokens taken from the purple / blue glass reference designs. */
object GlassColors {
    val Violet = Color(0xFF9B3DFF)
    val VioletSoft = Color(0xFFC58BFF)
    val Pink = Color(0xFFFF4D8D)
    val Ink = Color(0xFF0B0820)
    val TextDim = Color.White.copy(alpha = 0.66f)
}

@Composable
fun GlassTheme(content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = GlassColors.Violet,
        onPrimary = Color.White,
        background = GlassColors.Ink,
        surface = Color(0xFF1A1240),
        onSurface = Color.White,
        onBackground = Color.White,
        surfaceVariant = Color.White.copy(alpha = 0.12f),
        onSurfaceVariant = GlassColors.TextDim,
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

/** Deep indigo → violet → blue gradient with two soft colour blooms behind the glass. */
@Composable
fun GlassBackground(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    CompositionLocalProvider(LocalContentColor provides Color.White) {
        Box(
            modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF2A1260), Color(0xFF4A1C8C), Color(0xFF1E2A86), Color(0xFF0B0820))
                    )
                )
        ) {
            Box(
                Modifier.fillMaxSize().background(
                    Brush.radialGradient(
                        listOf(Color(0x66FF3DCB), Color.Transparent),
                        center = Offset(120f, 380f),
                        radius = 800f,
                    )
                )
            )
            Box(
                Modifier.fillMaxSize().background(
                    Brush.radialGradient(
                        listOf(Color(0x553D7BFF), Color.Transparent),
                        center = Offset(950f, 1700f),
                        radius = 1000f,
                    )
                )
            )
            content()
        }
    }
}

/** Frosted-glass surface: translucent white gradient fill + light edge. */
fun Modifier.glass(shape: Shape = RoundedCornerShape(24.dp), strong: Boolean = false): Modifier =
    this
        .clip(shape)
        .background(
            Brush.linearGradient(
                listOf(
                    Color.White.copy(alpha = if (strong) 0.24f else 0.15f),
                    Color.White.copy(alpha = if (strong) 0.10f else 0.05f),
                )
            )
        )
        .border(
            1.dp,
            Brush.linearGradient(listOf(Color.White.copy(alpha = 0.38f), Color.White.copy(alpha = 0.06f))),
            shape,
        )

@Composable
fun GlassIconButton(
    icon: ImageVector,
    desc: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    iconSize: Dp = 22.dp,
    active: Boolean = false,
    strong: Boolean = false,
) {
    Box(
        modifier
            .size(size)
            .glass(CircleShape, strong = strong || active)
            .then(if (active) Modifier.background(GlassColors.Violet.copy(alpha = 0.6f)) else Modifier)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, desc, tint = Color.White, modifier = Modifier.size(iconSize))
    }
}

@Composable
fun GlassChip(text: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Box(
        Modifier
            .height(36.dp)
            .clip(shape)
            .then(
                if (selected) Modifier.background(GlassColors.Violet)
                else Modifier.border(1.dp, Color.White.copy(alpha = 0.32f), shape)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = Color.White, style = MaterialTheme.typography.labelLarge)
    }
}

/** Floating pill navigation like the reference (selected item = violet circle). */
@Composable
fun GlassNavBar(
    items: List<Pair<String, ImageVector>>,
    selected: Int,
    onSelect: (Int) -> Unit,
) {
    Row(
        Modifier
            .navigationBarsPadding()
            .padding(bottom = 12.dp, top = 4.dp)
            .glass(RoundedCornerShape(36.dp), strong = true)
            .padding(8.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        items.forEachIndexed { i, (label, icon) ->
            Box(
                Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .then(if (i == selected) Modifier.background(GlassColors.Violet) else Modifier)
                    .clickable { onSelect(i) },
                contentAlignment = Alignment.Center,
            ) {
                Icon(icon, label, tint = Color.White)
            }
        }
    }
}

/** Audio-waveform style seek bar. progress is 0..1. */
@Composable
fun WaveformSeekBar(
    progress: Float,
    seed: String,
    onSeek: (Float) -> Unit,
    onSeekDone: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val bars = remember(seed) {
        val r = java.util.Random(seed.hashCode().toLong())
        var prev = 0.5f
        List(60) {
            // smoothed random so the bars look like a real waveform envelope
            prev = (prev * 0.45f + (0.15f + 0.85f * r.nextFloat()) * 0.55f)
            prev.coerceIn(0.12f, 1f)
        }
    }
    Canvas(
        modifier
            .pointerInput(Unit) {
                detectTapGestures { off ->
                    onSeek((off.x / size.width).coerceIn(0f, 1f))
                    onSeekDone()
                }
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { off -> onSeek((off.x / size.width).coerceIn(0f, 1f)) },
                    onDragEnd = { onSeekDone() },
                    onDragCancel = { onSeekDone() },
                ) { change, _ ->
                    onSeek((change.position.x / size.width).coerceIn(0f, 1f))
                }
            }
    ) {
        val n = bars.size
        val gap = 3.dp.toPx()
        val w = (size.width - gap * (n - 1)) / n
        bars.forEachIndexed { i, h ->
            val bh = size.height * h
            val played = (i + 0.5f) / n <= progress
            drawRoundRect(
                color = if (played) Color.White else Color.White.copy(alpha = 0.32f),
                topLeft = Offset(i * (w + gap), (size.height - bh) / 2f),
                size = Size(w, bh),
                cornerRadius = CornerRadius(w / 2f),
            )
        }
    }
}
