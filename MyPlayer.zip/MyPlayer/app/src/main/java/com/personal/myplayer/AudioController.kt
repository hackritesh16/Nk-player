package com.personal.myplayer

import android.content.ComponentName
import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture

/** Compose-friendly wrapper around a MediaController connected to PlaybackService. */
class AudioController(private val ctx: Context) {
    private var future: ListenableFuture<MediaController>? = null
    private var player: MediaController? = null
    private var pending: (() -> Unit)? = null
    private var saveCounter = 0
    private val handler = Handler(Looper.getMainLooper())
    private val sleepRunnable = Runnable {
        player?.pause()
        sleepEndsAt = 0L
    }

    var hasMedia by mutableStateOf(false)
    var isPlaying by mutableStateOf(false)
    var title by mutableStateOf("")
    var artist by mutableStateOf("")
    var currentKey by mutableStateOf("")
    var positionMs by mutableLongStateOf(0L)
    var durationMs by mutableLongStateOf(0L)
    var shuffle by mutableStateOf(false)
    var repeatMode by mutableIntStateOf(Player.REPEAT_MODE_OFF)
    var speed by mutableFloatStateOf(1f)
    var sleepEndsAt by mutableLongStateOf(0L)

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            sync(player)
            if (events.contains(Player.EVENT_MEDIA_ITEM_TRANSITION)) {
                val id = player.currentMediaItem?.mediaId.orEmpty()
                if (id.isNotEmpty()) Prefs.addHistory(id)
            }
            if (events.contains(Player.EVENT_IS_PLAYING_CHANGED) && !player.isPlaying) savePos(player)
        }

        override fun onPositionDiscontinuity(
            oldPosition: Player.PositionInfo,
            newPosition: Player.PositionInfo,
            reason: Int
        ) {
            val oldId = oldPosition.mediaItem?.mediaId.orEmpty()
            val newId = newPosition.mediaItem?.mediaId.orEmpty()
            if (oldId.isNotEmpty() && oldId != newId) {
                Prefs.setPos(
                    oldId,
                    if (reason == Player.DISCONTINUITY_REASON_AUTO_TRANSITION) 0L else oldPosition.positionMs
                )
            }
        }
    }

    fun connect() {
        if (future != null) return
        val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        val f = MediaController.Builder(ctx, token).buildAsync()
        future = f
        f.addListener({
            try {
                val c = f.get()
                player = c
                c.addListener(listener)
                sync(c)
                pending?.invoke()
                pending = null
            } catch (e: Exception) {
                // service could not be reached; ignore
            }
        }, ContextCompat.getMainExecutor(ctx))
    }

    fun release() {
        handler.removeCallbacksAndMessages(null)
        future?.let { MediaController.releaseFuture(it) }
        future = null
        player = null
    }

    private fun sync(p: Player) {
        hasMedia = p.mediaItemCount > 0
        isPlaying = p.isPlaying
        title = p.mediaMetadata.title?.toString().orEmpty()
        artist = p.mediaMetadata.artist?.toString().orEmpty()
        durationMs = p.duration.coerceAtLeast(0L)
        shuffle = p.shuffleModeEnabled
        repeatMode = p.repeatMode
        speed = p.playbackParameters.speed
        currentKey = p.currentMediaItem?.mediaId.orEmpty()
    }

    private fun savePos(p: Player) {
        val id = p.currentMediaItem?.mediaId.orEmpty()
        if (id.isNotEmpty()) Prefs.savePos(id, p.currentPosition, p.duration)
    }

    /** Call about twice per second from the UI. */
    fun tick() {
        val c = player ?: return
        positionMs = c.currentPosition.coerceAtLeast(0L)
        durationMs = c.duration.coerceAtLeast(0L)
        if (c.isPlaying) {
            saveCounter++
            if (saveCounter % 10 == 0) savePos(c)
        }
    }

    fun play(list: List<MediaFile>, index: Int) {
        if (list.isEmpty()) return
        val action: () -> Unit = {
            val c = player
            if (c != null) {
                val items: List<MediaItem> = list.map { it.toMediaItem() }
                val i = index.coerceIn(0, list.size - 1)
                val saved = Prefs.getPos(list[i].key)
                val dur = list[i].durationMs
                val start = if (saved > 3_000 && (dur <= 0 || dur - saved > 5_000)) saved else 0L
                c.setMediaItems(items, i, start)
                c.prepare()
                c.play()
            }
        }
        if (player != null) action() else pending = action
    }

    fun togglePlay() {
        val c = player ?: return
        if (c.isPlaying) c.pause() else c.play()
    }

    fun next() { player?.seekToNextMediaItem() }
    fun previous() { player?.seekToPrevious() }
    fun seekTo(ms: Long) { player?.seekTo(ms) }

    fun toggleShuffle() {
        val c = player ?: return
        c.shuffleModeEnabled = !c.shuffleModeEnabled
    }

    fun cycleRepeat() {
        val c = player ?: return
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    // Not named setSpeed: `var speed` already generates a JVM setSpeed(float) -> platform declaration clash
    fun changeSpeed(s: Float) { player?.setPlaybackSpeed(s) }

    fun setSleepTimer(minutes: Int) {
        handler.removeCallbacks(sleepRunnable)
        if (minutes <= 0) {
            sleepEndsAt = 0L
            return
        }
        val ms = minutes * 60_000L
        sleepEndsAt = System.currentTimeMillis() + ms
        handler.postDelayed(sleepRunnable, ms)
    }

    /** Stops playback and removes the notification. */
    fun close() {
        val c = player ?: return
        savePos(c)
        c.stop()
        c.clearMediaItems()
        setSleepTimer(0)
    }
}
