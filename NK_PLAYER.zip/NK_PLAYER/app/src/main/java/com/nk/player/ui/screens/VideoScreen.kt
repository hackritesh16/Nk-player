package com.nk.player.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.nk.player.data.model.MediaItem
import com.nk.player.ui.components.GlassCard
import com.nk.player.ui.theme.NKColors
import com.nk.player.utils.fmtDuration

@Composable
fun VideoScreen(videos: List<MediaItem>, onPlay: (List<MediaItem>, Int)->Unit){
    Column(Modifier.fillMaxSize().background(NKColors.Bg).padding(16.dp)){
        Text("Videos", style = MaterialTheme.typography.displayMedium, color = NKColors.TextPri)
        Text("${videos.size} videos • tap to play • swipe gestures in player", color = NKColors.TextSec, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(16.dp))
        if(videos.isEmpty()){
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center){ Text("No videos found", color = NKColors.TextSec) }
        } else {
            LazyVerticalGrid(columns = GridCells.Adaptive(160.dp), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxSize()){
                items(videos, key = { it.id }){ v ->
                    GlassCard(modifier = Modifier.clickable{ onPlay(videos, videos.indexOf(v)) }){
                        Column(Modifier.padding(12.dp)){
                            Box(Modifier.fillMaxWidth().height(96.dp).clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(listOf(NKColors.Violet, NKColors.Cyan))), contentAlignment = Alignment.Center){
                                Icon(Icons.Default.Videocam, null, tint = Color.White, modifier = Modifier.size(32.dp))
                                Box(Modifier.align(Alignment.BottomEnd).padding(6.dp).clip(RoundedCornerShape(8.dp)).background(Color(0x99000000)).padding(horizontal = 6.dp, vertical = 2.dp)){
                                    Text(fmtDuration(v.durationMs), color = Color.White, style = MaterialTheme.typography.labelSmall)
                                }
                                Box(Modifier.align(Alignment.Center).clip(RoundedCornerShape(50)).background(Color(0x33000000)).padding(10.dp)){
                                    Icon(Icons.Default.PlayArrow, null, tint = Color.White)
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(v.title, color = NKColors.TextPri, style = MaterialTheme.typography.titleMedium, maxLines = 2)
                            Text(v.path.substringAfterLast("/").take(32), color = NKColors.TextMuted, style = MaterialTheme.typography.bodyMedium, maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}
