@echo off
echo Run: gradle wrapper --gradle-version 8.6  OR open in Android Studio to generate wrapper
exit /b 1
