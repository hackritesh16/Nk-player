# MyPlayer

Personal video + audio player for Android (Kotlin, Jetpack Compose, Media3/ExoPlayer + FFmpeg decoders).

## APK banane ka tareeka (GitHub)
1. Is poore folder ko ek naye GitHub repo mein push karo (branch `main`).
2. Repo > **Actions** tab > "Build APK" workflow apne aap chalega (ya "Run workflow" dabao).
3. Workflow khatam hone par run ke neeche **Artifacts > MyPlayer-apk** download karo.
4. Zip ke andar `debug/app-debug.apk` aur `release/app-release.apk` milenge. Phone mein install karo.

## Features
- Local videos (folders) + music library, search, sort, favourites, history, resume playback
- Video: gestures (brightness / volume / seek), double-tap +-10s, long-press 2x, speed 0.5x-4x,
  aspect ratio, rotate, subtitles (built-in tracks + external SRT/VTT/ASS), audio tracks, PiP
- Music: background play, notification + lock-screen controls, shuffle, repeat, speed, sleep timer
- "Open any file" aur "Play network stream" (HLS, DASH, RTSP, http)
- FFmpeg decoders (AC3, DTS, TrueHD, Opus, FLAC, Vorbis, HEVC, VP9...) fallback ke liye
