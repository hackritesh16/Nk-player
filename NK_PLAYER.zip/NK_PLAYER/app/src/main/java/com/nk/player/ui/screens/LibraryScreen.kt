package com.nk.player.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nk.player.data.model.MediaItem
import com.nk.player.ui.components.GlassCard
import com.nk.player.ui.theme.NKColors
import com.nk.player.utils.fmtDuration

@Composable
fun LibraryScreen(
    audio: List<MediaItem>,
    video: List<MediaItem>,
    query: String,
    onQuery: (String)->Unit,
    onPlay: (List<MediaItem>, Int)->Unit,
    onShuffleAll: ()->Unit,
    onToggleFav: (MediaItem)->Unit,
    favUris: Set<String>,
){
    var tab by remember { mutableStateOf(0) } // 0 songs, 1 videos, 2 all
    val base = when(tab){0->audio; 1->video; else-> audio+video}
    val filtered = remember(base, query){
        if(query.isBlank()) base else base.filter{
            it.title.contains(query, true) || (it.artist?.contains(query,true) == true)
        }
    }

    Column(Modifier.fillMaxSize().background(NKColors.Bg).padding(16.dp)) {
        // Header
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()){
            Box(Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(NKColors.Cyan, NKColors.Violet))), contentAlignment = Alignment.Center){
                Text("NK", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)){
                Text("NK PLAYER", style = MaterialTheme.typography.titleLarge, color = NKColors.TextPri, fontWeight = FontWeight.Black)
                Text("${audio.size} songs • ${video.size} videos", style = MaterialTheme.typography.bodyMedium, color = NKColors.TextSec)
            }
            IconButton(onClick = onShuffleAll){ Icon(Icons.Default.Shuffle, null, tint = NKColors.Cyan) }
        }
        Spacer(Modifier.height(16.dp))

        // Search
        GlassCard { Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically){
            Icon(Icons.Default.Search, null, tint = NKColors.TextSec)
            Spacer(Modifier.width(8.dp))
            TextField(value = query, onValueChange = onQuery, placeholder = { Text("Search music & videos…", color = NKColors.TextMuted) },
                colors = TextFieldDefaults.colors(focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent, focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent),
                modifier = Modifier.weight(1f))
            if(query.isNotEmpty()) IconButton(onClick = { onQuery("") }){ Icon(Icons.Default.Close, null, tint = NKColors.TextSec) }
        } }

        Spacer(Modifier.height(12.dp))
        // Tabs
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)){
            listOf("Songs","Videos","All").forEachIndexed{ i, t ->
                val sel = i==tab
                FilterChip(selected = sel, onClick = { tab = i }, label = { Text(t) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = NKColors.Cyan, selectedLabelColor = NKColors.Bg, containerColor = NKColors.Glass),
                    border = FilterChipDefaults.filterChipBorder(enabled = true, selected = sel, borderColor = if(sel) NKColors.Cyan else NKColors.GlassBorder)
                )
            }
        }
        Spacer(Modifier.height(12.dp))

        if(filtered.isEmpty()){
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center){
                Column(horizontalAlignment = Alignment.CenterHorizontally){
                    Icon(Icons.Default.MusicNote, null, tint = NKColors.TextMuted, modifier = Modifier.size(48.dp))
                    Spacer(Modifier.height(8.dp))
                    Text("No media found", color = NKColors.TextSec)
                    if(query.isNotBlank()) Text("Try a different search", color = NKColors.TextMuted, style = MaterialTheme.typography.bodyMedium)
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxSize()){
                items(filtered, key = { it.id }){ m ->
                    MediaRow(m, isFav = favUris.contains(m.uri.toString()), onPlay = {
                        val idx = base.indexOf(m).coerceAtLeast(0)
                        onPlay(base, idx)
                    }, onFav = { onToggleFav(m) })
                }
            }
        }
    }
}

@Composable
private fun MediaRow(m: MediaItem, isFav: Boolean, onPlay: ()->Unit, onFav: ()->Unit){
    GlassCard(modifier = Modifier.clickable{ onPlay() }){
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically){
            Box(Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(
                if(m.isVideo) Brush.linearGradient(listOf(NKColors.Violet, NKColors.Pink)) else Brush.linearGradient(listOf(NKColors.Cyan, NKColors.Violet))
            ), contentAlignment = Alignment.Center){
                Icon(if(m.isVideo) Icons.Default.Videocam else Icons.Default.MusicNote, null, tint = Color.White)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)){
                Text(m.title, color = NKColors.TextPri, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                Text(listOfNotNull(m.artist, m.album).joinToString(" • ").ifEmpty { if(m.isVideo) "Video" else "Audio" } + "  •  " + fmtDuration(m.durationMs),
                    color = NKColors.TextSec, style = MaterialTheme.typography.bodyMedium, maxLines = 1)
            }
            IconButton(onClick = onFav){ Icon(if(isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if(isFav) NKColors.Pink else NKColors.TextSec) }
            Icon(Icons.Default.PlayArrow, null, tint = NKColors.Cyan)
        }
    }
}
