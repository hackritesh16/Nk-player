package com.personal.myplayer

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LibraryViewModel(app: Application) : AndroidViewModel(app) {
    var loading by mutableStateOf(true)
        private set
    var videos by mutableStateOf<List<MediaFile>>(emptyList())
        private set
    var audios by mutableStateOf<List<MediaFile>>(emptyList())
        private set
    var favs by mutableStateOf<Set<String>>(emptySet())
        private set
    var history by mutableStateOf<List<String>>(emptyList())
        private set
    var tick by mutableIntStateOf(0)
        private set

    init {
        favs = Prefs.favourites()
        history = Prefs.history()
    }

    fun load() {
        viewModelScope.launch {
            loading = true
            val all = withContext(Dispatchers.IO) { MediaRepo.load(getApplication<Application>()) }
            videos = all.filter { it.isVideo }
            audios = all.filter { !it.isVideo }
            loading = false
        }
    }

    fun toggleFav(f: MediaFile) {
        favs = Prefs.toggleFav(f.key)
    }

    fun clearHistory() {
        Prefs.clearHistory()
        history = emptyList()
    }

    /** Re-read resume positions / history (called when the app comes back to the foreground). */
    fun refresh() {
        history = Prefs.history()
        favs = Prefs.favourites()
        tick++
    }

    fun byKey(key: String): MediaFile? =
        (audios + videos).firstOrNull { it.key == key }
}
