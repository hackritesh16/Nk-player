package com.nk.player.playback

import android.content.Context
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

object PlayerManager {
    var exo: ExoPlayer? = null
        private set

    private val _queue = MutableStateFlow<List<MediaItem>>(emptyList())
    val queue: StateFlow<List<MediaItem>> = _queue
    private val _index = MutableStateFlow(0)
    val index: StateFlow<Int> = _index

    fun ensure(context: Context): ExoPlayer {
        if (exo != null) return exo!!
        exo = ExoPlayer.Builder(context).build().also { p ->
            p.repeatMode = Player.REPEAT_MODE_OFF
            p.addListener(object: Player.Listener{
                override fun onMediaItemTransition(item: MediaItem?, reason: Int){
                    _index.value = p.currentMediaItemIndex
                }
            })
        }
        return exo!!
    }

    fun setQueue(player: ExoPlayer, items: List<MediaItem>, startIndex: Int = 0){
        _queue.value = items
        _index.value = startIndex.coerceIn(0, (items.size-1).coerceAtLeast(0))
        player.setMediaItems(items, _index.value, 0)
        player.prepare(); player.play()
    }
    fun release(){ exo?.release(); exo = null }
}
