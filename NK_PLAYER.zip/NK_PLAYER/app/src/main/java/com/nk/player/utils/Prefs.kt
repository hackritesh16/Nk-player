package com.nk.player.utils

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.ds by preferencesDataStore("nk_prefs")

object Prefs {
    private lateinit var app: Context
    fun init(c: Context){ app = c.applicationContext }

    private val THEME = stringPreferencesKey("theme") // dark | neon | amoled
    private val SPEED = floatPreferencesKey("speed")
    private val REPEAT = stringPreferencesKey("repeat") // off | one | all
    private val SHUFFLE = booleanPreferencesKey("shuffle")
    private val SLEEP = longPreferencesKey("sleep_ms")
    private val EQ = stringPreferencesKey("eq_preset")

    // Resolve DataStore only when a caller reads the flow, after init() has run.
    val theme: Flow<String> get() = app.ds.data.map { it[THEME] ?: "dark" }
    val speed: Flow<Float> get() = app.ds.data.map { it[SPEED] ?: 1f }
    val repeat: Flow<String> get() = app.ds.data.map { it[REPEAT] ?: "off" }
    val shuffle: Flow<Boolean> get() = app.ds.data.map { it[SHUFFLE] ?: false }
    val eqPreset: Flow<String> get() = app.ds.data.map { it[EQ] ?: "Flat" }

    suspend fun setTheme(v: String){ app.ds.edit{ it[THEME]=v } }
    suspend fun setSpeed(v: Float){ app.ds.edit{ it[SPEED]=v } }
    suspend fun setRepeat(v: String){ app.ds.edit{ it[REPEAT]=v } }
    suspend fun setShuffle(v: Boolean){ app.ds.edit{ it[SHUFFLE]=v } }
    suspend fun setEq(v: String){ app.ds.edit{ it[EQ]=v } }

    // Non-flow snapshot helpers (for playback service quick reads)
    suspend fun snapshotTheme(): String = app.ds.data.map { it[THEME] ?: "dark" }.first()
}
