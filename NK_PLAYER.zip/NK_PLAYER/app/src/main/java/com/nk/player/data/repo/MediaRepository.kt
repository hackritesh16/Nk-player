package com.nk.player.data.repo

import android.content.ContentUris
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.provider.MediaStore
import com.nk.player.data.model.MediaItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object MediaRepository {

    suspend fun loadAudio(context: Context): List<MediaItem> = withContext(Dispatchers.IO) {
        query(context, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, false)
    }
    suspend fun loadVideo(context: Context): List<MediaItem> = withContext(Dispatchers.IO) {
        query(context, MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true)
    }
    suspend fun loadAll(context: Context): List<MediaItem> = withContext(Dispatchers.IO) {
        loadAudio(context) + loadVideo(context)
    }

    private fun query(context: Context, uri: Uri, isVideo: Boolean): List<MediaItem> {
        val out = mutableListOf<MediaItem>()
        val proj = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.TITLE,
            MediaStore.MediaColumns.MIME_TYPE,
            MediaStore.MediaColumns.DATA,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_ADDED,
            if (isVideo) MediaStore.Video.Media.DURATION else MediaStore.Audio.Media.DURATION,
            if (isVideo) MediaStore.Video.Media.WIDTH else MediaStore.Audio.Media.ALBUM,
            if (isVideo) MediaStore.Video.Media.HEIGHT else MediaStore.Audio.Media.ARTIST,
            if (!isVideo) MediaStore.Audio.Media.ALBUM else MediaStore.Video.Media.RESOLUTION,
            if (!isVideo) MediaStore.Audio.Media.ARTIST else MediaStore.Video.Media.DESCRIPTION,
        )
        var c: Cursor? = null
        try {
            c = context.contentResolver.query(uri, null, null, null, "${MediaStore.MediaColumns.DATE_ADDED} DESC")
            if (c == null) return out
            val idIdx = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val titleIdx = c.getColumnIndex(MediaStore.MediaColumns.TITLE)
            val displayIdx = c.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME)
            val mimeIdx = c.getColumnIndex(MediaStore.MediaColumns.MIME_TYPE)
            val dataIdx = c.getColumnIndex(MediaStore.MediaColumns.DATA)
            val sizeIdx = c.getColumnIndex(MediaStore.MediaColumns.SIZE)
            val dateIdx = c.getColumnIndex(MediaStore.MediaColumns.DATE_ADDED)
            val durIdx = c.getColumnIndex(if (isVideo) MediaStore.Video.Media.DURATION else MediaStore.Audio.Media.DURATION)
            val artistIdx = if (!isVideo) c.getColumnIndex(MediaStore.Audio.Media.ARTIST) else -1
            val albumIdx = if (!isVideo) c.getColumnIndex(MediaStore.Audio.Media.ALBUM) else -1
            while (c.moveToNext()) {
                val id = c.getLong(idIdx)
                val title = (if (titleIdx >= 0) c.getString(titleIdx) else null)?.takeIf { it.isNotBlank() }
                    ?: c.getString(displayIdx) ?: "Unknown"
                val mime = if (mimeIdx >= 0) c.getString(mimeIdx) else null
                val path = if (dataIdx >= 0) c.getString(dataIdx) ?: "" else ""
                val size = if (sizeIdx >= 0) c.getLong(sizeIdx) else 0L
                val date = if (dateIdx >= 0) c.getLong(dateIdx) else 0L
                val dur = if (durIdx >= 0) c.getLong(durIdx) else 0L
                val artist = if (artistIdx >= 0) c.getString(artistIdx) else null
                val album = if (albumIdx >= 0) c.getString(albumIdx) else null
                val contentUri = ContentUris.withAppendedId(uri, id)
                // filter 0-byte / trash
                if (size == 0L && dur == 0L) continue
                out += MediaItem(id, contentUri, title, artist, album, dur, isVideo, path, mime, date, size)
            }
        } catch (_: Exception) {}
        finally { c?.close() }
        return out
    }
}
