package com.nk.player.data.model

import android.net.Uri

data class MediaItem(
    val id: Long,
    val uri: Uri,
    val title: String,
    val artist: String?,
    val album: String?,
    val durationMs: Long,
    val isVideo: Boolean,
    val path: String,
    val mime: String?,
    val dateAdded: Long,
    val sizeBytes: Long,
    val width: Int = 0,
    val height: Int = 0,
)

data class Playlist(
    val id: Long,
    val name: String,
    val count: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

data class PlaylistEntry(
    val playlistId: Long,
    val mediaId: Long,
    val position: Int
)

data class FolderEntry(
    val path: String,
    val count: Int,
    val totalDurationMs: Long
)
