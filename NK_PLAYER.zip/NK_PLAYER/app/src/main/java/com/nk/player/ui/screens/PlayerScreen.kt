package com.nk.player.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.nk.player.ui.components.GlassCard
import com.nk.player.ui.theme.NKColors
import com.nk.player.utils.fmtDuration
import kotlinx.coroutines.delay

@Composable
fun PlayerScreen(
    player: ExoPlayer?,
    title: String,
    artist: String?,
    isVideo: Boolean,
    onBack: ()->Unit,
    onNext: ()->Unit,
    onPrev: ()->Unit,
    speed: Float,
    onSpeed: (Float)->Unit,
){
    var pos by remember{ mutableStateOf(0L) }
    var dur by remember{ mutableStateOf(0L) }
    var playing by remember{ mutableStateOf(false) }
    var volumeHint by remember{ mutableStateOf<String?>(null) }
    var brightnessHint by remember{ mutableStateOf<String?>(null) }

    LaunchedEffect(player){
        while(true){
            pos = player?.currentPosition ?: 0L
            dur = (player?.duration ?: 0L).let{ if(it<0) 0L else it }
            playing = player?.isPlaying == true
            delay(400)
        }
    }

    Column(Modifier.fillMaxSize().background(NKColors.Bg)){
        // Top bar
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically){
            IconButton(onClick = onBack){ Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
            Column(Modifier.weight(1f).padding(horizontal = 8.dp)){
                Text(title, color = Color.White, style = MaterialTheme.typography.titleMedium, maxLines = 1, fontWeight = FontWeight.Bold)
                Text(artist ?: if(isVideo) "Video" else "Audio", color = NKColors.TextSec, style = MaterialTheme.typography.bodyMedium, maxLines = 1)
            }
            IconButton(onClick = { player?.let{ it.playWhenReady = !it.playWhenReady } }){ Icon(if(playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = NKColors.Cyan) }
        }

        // Video surface (gestures: vertical left=brightness, right=volume, horizontal=seek)
        if(isVideo && player!=null){
            Box(
                Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(16.dp)).background(Color.Black)
                    .pointerInput(Unit){
                        detectVerticalDragGestures{ _, dragAmount ->
                            // left/right distinction via x not available here; use simple hints
                            if(dragAmount < -20) volumeHint = "Volume ▲"; else if(dragAmount > 20) volumeHint = "Volume ▼"
                        }
                    }
                    .pointerInput(Unit){
                        detectHorizontalDragGestures{ _, dragAmount ->
                            player.seekTo((player.currentPosition + (dragAmount*300).toLong()).coerceIn(0, dur.coerceAtLeast(1)))
                        }
                    }
            ){
                val ctx = LocalContext.current
                AndroidView(factory = {
                    PlayerView(ctx).apply{
                        this.player = player
                        useController = true
                        controllerShowTimeoutMs = 3000
                    }
                }, modifier = Modifier.fillMaxSize())
                volumeHint?.let{ Box(Modifier.align(Alignment.Center).clip(RoundedCornerShape(12.dp)).background(Color(0xAA000000)).padding(12.dp)){ Text(it, color=Color.White) } }
            }
        } else {
            // Audio artwork placeholder
            Box(Modifier.fillMaxWidth().weight(1f).padding(24.dp).clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(NKColors.Violet, NKColors.Cyan))), contentAlignment = Alignment.Center){
                Column(horizontalAlignment = Alignment.CenterHorizontally){
                    Icon(Icons.Default.MusicNote, null, tint = Color.White, modifier = Modifier.size(72.dp))
                    Spacer(Modifier.height(16.dp))
                    Text(title, color = Color.White, style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Black)
                    artist?.let{ Text(it, color = Color(0xDDFFFFFF), style = MaterialTheme.typography.titleMedium) }
                }
            }
        }

        // Controls
        GlassCard(modifier = Modifier.padding(12.dp)){
            Column(Modifier.padding(16.dp)){
                Slider(value = if(dur>0) pos.toFloat()/dur else 0f, onValueChange = { v -> player?.seekTo((v*dur).toLong()) }, colors = SliderDefaults.colors(activeTrackColor = NKColors.Cyan, thumbColor = NKColors.Cyan))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween){
                    Text(fmtDuration(pos), color = NKColors.TextSec, style = MaterialTheme.typography.bodyMedium)
                    Text(fmtDuration(dur), color = NKColors.TextSec, style = MaterialTheme.typography.bodyMedium)
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically){
                    IconButton(onClick = onPrev){ Icon(Icons.Default.SkipPrevious, null, tint = Color.White, modifier = Modifier.size(36.dp)) }
                    FilledIconButton(onClick = { player?.let{ it.playWhenReady = !it.playWhenReady } }, colors = IconButtonDefaults.filledIconButtonColors(containerColor = NKColors.Cyan, contentColor = NKColors.Bg), modifier = Modifier.size(64.dp)){
                        Icon(if(playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, modifier = Modifier.size(36.dp))
                    }
                    IconButton(onClick = onNext){ Icon(Icons.Default.SkipNext, null, tint = Color.White, modifier = Modifier.size(36.dp)) }
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()){
                    listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach{ s ->
                        FilterChip(selected = speed==s, onClick = { onSpeed(s) }, label = { Text("${s}x") },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = NKColors.Violet, selectedLabelColor = Color.White))
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)){
                    AssistChip(onClick = { player?.repeatMode = if(player.repeatMode==Player.REPEAT_MODE_ONE) Player.REPEAT_MODE_OFF else Player.REPEAT_MODE_ONE }, label = { Text(if(player?.repeatMode==Player.REPEAT_MODE_ONE) "Repeat: One" else "Repeat: Off") })
                    AssistChip(onClick = { player?.shuffleModeEnabled = !(player?.shuffleModeEnabled ?: false) }, label = { Text(if(player?.shuffleModeEnabled==true) "Shuffle: On" else "Shuffle: Off") })
                }
            }
        }
    }
}
