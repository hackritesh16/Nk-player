package com.nk.player

import android.app.Application
import com.nk.player.utils.Prefs

class NKPlayerApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
    }
}
