package com.nk.player.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nk.player.data.model.MediaItem
import com.nk.player.ui.components.GlassCard
import com.nk.player.ui.theme.NKColors
import com.nk.player.utils.fmtDuration

@Composable
fun FoldersScreen(all: List<MediaItem>, onPlay: (List<MediaItem>, Int)->Unit){
    val grouped = remember(all){ all.groupBy{ it.path.substringBeforeLast("/", missingDelimiterValue = "/storage") }.toList().sortedByDescending{ it.second.size } }
    var selected: String? by remember{ mutableStateOf(null) }
    val list = if(selected==null) grouped else grouped.filter{ it.first==selected }

    Column(Modifier.fillMaxSize().background(NKColors.Bg).padding(16.dp)){
        Text("Folders", style = MaterialTheme.typography.displayMedium, color = NKColors.TextPri)
        Text("${grouped.size} folders • ${all.size} files", color = NKColors.TextSec, style = MaterialTheme.typography.bodyMedium)
        if(selected!=null){ Spacer(Modifier.height(8.dp)); AssistChip(onClick = { selected=null }, label = { Text("← Back to folders") }) }
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxSize()){
            if(selected==null){
                items(grouped, key = { it.first }){ (path, items) ->
                    GlassCard(modifier = Modifier.clickable{ selected = path }){
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically){
                            Icon(Icons.Default.Folder, null, tint = NKColors.Cyan)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)){
                                Text(path, color = NKColors.TextPri, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                                Text("${items.size} items • ${fmtDuration(items.sumOf{ it.durationMs })}", color = NKColors.TextSec, style = MaterialTheme.typography.bodyMedium)
                            }
                            Text("›", color = NKColors.TextSec, style = MaterialTheme.typography.titleLarge)
                        }
                    }
                }
            } else {
                val items = list.firstOrNull()?.second ?: emptyList()
                items(items, key = { it.id }){ m ->
                    GlassCard(modifier = Modifier.clickable{ onPlay(items, items.indexOf(m)) }){
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically){
                            Column(Modifier.weight(1f)){
                                Text(m.title, color = NKColors.TextPri, maxLines = 1)
                                Text(fmtDuration(m.durationMs) + " • " + m.path.substringAfterLast("/"), color = NKColors.TextSec, style = MaterialTheme.typography.bodyMedium, maxLines = 1)
                            }
                            Text("▶", color = NKColors.Cyan)
                        }
                    }
                }
            }
        }
    }
}
