package com.personal.myplayer

import android.content.Context
import android.graphics.Bitmap
import android.util.LruCache
import android.util.Size
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object ThumbCache {
    private val cache = LruCache<String, Bitmap>(150)

    fun get(ctx: Context, f: MediaFile, px: Int): Bitmap? {
        val k = "${f.key}@$px"
        cache.get(k)?.let { return it }
        val b = try {
            ctx.contentResolver.loadThumbnail(f.uri, Size(px, px), null)
        } catch (e: Exception) {
            null
        }
        if (b != null) cache.put(k, b)
        return b
    }
}

/** Cover art (audio) or video frame thumbnail, with an icon placeholder. */
@Composable
fun Thumb(
    f: MediaFile?,
    modifier: Modifier,
    px: Int,
    shape: Shape = RoundedCornerShape(12.dp),
    iconSize: Dp = 24.dp,
) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(initialValue = null, f?.key) {
        value = if (f == null) null else withContext(Dispatchers.IO) { ThumbCache.get(ctx, f, px) }
    }
    Box(
        modifier.clip(shape).background(Color.White.copy(alpha = 0.12f)),
        contentAlignment = Alignment.Center,
    ) {
        val b = bmp
        if (b != null) {
            Image(
                bitmap = b.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        } else {
            Icon(
                if (f?.isVideo == true) Icons.Filled.Movie else Icons.Filled.MusicNote,
                null,
                tint = Color.White.copy(alpha = 0.7f),
                modifier = Modifier.size(iconSize),
            )
        }
    }
}
